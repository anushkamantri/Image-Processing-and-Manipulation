package layeredimages;

import images.ImageModel;
import java.util.Stack;

/**
 * To represent layered images. A layered image has one or more layers with each layer behaving as a
 * separate image.
 *
 * @param <K> the pixel type
 */
public interface LayeredImageModel<K> extends ImageModel<K> {

  /**
   * Creates a blank layer to be added to the stack of layers.
   */
  void createLayer(String name);

  /**
   * Creates a copy of an already existing layer at the given index to be added to the stack of
   * layers.
   *
   * @throws IllegalArgumentException if the index is invalid
   */
  void addLayerCopy(String layerName) throws IllegalArgumentException;

  /**
   * Deletes the layer at the given index in the stack.
   *
   * @param name the name of a layer that is to be deleted
   * @throws IllegalArgumentException if the name is invalid
   */
  void removeLayer(String name) throws IllegalArgumentException;

  /**
   * Gives a copy of the stack of layers.
   *
   * @return a copy of the stack of layers
   */
  Stack<Layer> getAllLayers();

  /**
   * Sets the name of layer at the given index to the given layer name.
   *
   * @param index     the index at which the layer is to be set
   * @param layerName the new name for the layer
   * @throws IllegalArgumentException if there's no layer corresponding to the given index or if the
   *                                  given layer name is null
   */
  void setLayerName(int index, String layerName) throws IllegalArgumentException;

  /**
   * Gets the layer with the given layer name.
   *
   * @param name the name of the layer to be returned
   * @return the {@code Layer} corresponding to the given name
   * @throws IllegalArgumentException if there's no layer corresponding to the given name
   */
  Layer getLayer(String name) throws IllegalArgumentException;

  /**
   * Gets the current layer in this layered image model.
   *
   * @return the current {@code Layer}
   * @throws IllegalArgumentException if there's no layer that is the current layer
   */
  Layer getCurrent() throws IllegalArgumentException;

  /**
   * Makes the layer with the given name the current layer.
   *
   * @param name the name corresponding to the layer to be made the current layer
   */
  void setCurrent(String name);

  Layer getTopVisibleLayer();

}
