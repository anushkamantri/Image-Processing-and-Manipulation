package layeredimages;

import images.ImageModel;
import images.Pixel;
import images.RGBClr;
import images.SimpleImageModel;
import java.util.Stack;

/**
 * To represent an image with layers. An image can be composed of one or more layers, with different
 * operations that can be applied to any layer.
 */
public class SimpleLayeredImageModel implements LayeredImageModel<Pixel> {

  private final ImageModel<Pixel> delegate;
  private final Stack<Layer> layerOfImages;
  private Layer current;


  /**
   * Constructs a {@code SimpleLayeredImageModel}.
   *
   * @param model the model to be used to apply operations to the image
   */
  public SimpleLayeredImageModel(ImageModel<Pixel> model) {
    if (model == null) {
      throw new IllegalArgumentException("Model can't be null.");
    }

    delegate = model;
    this.layerOfImages = new Stack<>();
  }

  @Override
  public ImageModel<Pixel> filterUsing(String filterName) throws IllegalArgumentException {
    current.setImage(delegate.filterUsing(filterName));

    return current.getImage();
  }

  @Override
  public ImageModel<Pixel> transformUsing(String transformationName)
      throws IllegalArgumentException {
    current.setImage(delegate.transformUsing(transformationName));

    return current.getImage();
  }

  @Override
  public ImageModel<Pixel> createProgrammaticImageUsing(String progImageName, int tileSize,
      int tilesInARow, RGBClr[] clrs) throws IllegalArgumentException {
    current.setImage(
        delegate.createProgrammaticImageUsing(progImageName, tileSize, tilesInARow, clrs));

    return current.getImage();
  }


  @Override
  public int getWidth() {
    return delegate.getWidth();
  }

  @Override
  public int getHeight() {
    return delegate.getHeight();
  }

  @Override
  public Pixel[][] getPixels() {
    return delegate.getPixels();
  }

  @Override
  public ImageModel<Pixel> getImage() {
    return delegate.getImage();
  }


  @Override
  public void createLayer(String name) {
    if (layerOfImages.isEmpty()) {
      layerOfImages
          .push(new Layer(new SimpleLayeredImageModel(new SimpleImageModel(
              delegate.getWidth(), delegate.getHeight(), delegate.getPixels())),
              true, name));
    } else {
      layerOfImages
          .push(new Layer(new SimpleLayeredImageModel(new SimpleImageModel(
              layerOfImages.get(0).getImage().getWidth(),
              layerOfImages.get(0).getImage().getHeight(),
              layerOfImages.get(0).getImage().getPixels())), true, name));
    }
  }

  @Override
  public void addLayerCopy(String layerName) {
    layerOfImages
        .push(new Layer(new SimpleLayeredImageModel(new SimpleImageModel(
            getLayer(layerName).getImage().getWidth(),
            getLayer(layerName).getImage().getHeight(),
            getLayer(layerName).getImage().getPixels())),
            true, "copy_layer_" + (layerName) + "_" + layerOfImages.size()));
  }

  @Override
  public void removeLayer(String layerName) {
    if (getAllLayers().size() != 0) {
      if (layerOfImages.contains(getLayer(layerName))) {
        layerOfImages.remove(getLayer(layerName));
      } else {
        throw new IllegalArgumentException("Stack does not contain the given layer");
      }
    } else {
      throw new IllegalArgumentException("Cannot remove a layer from an empty stack");
    }
  }

  @Override
  public Stack<Layer> getAllLayers() {
    Stack<Layer> newStack = new Stack<>();

    for (Layer layer : layerOfImages) {
      try {
        layer.getImage();
      } catch (NullPointerException e) {
        throw new IllegalArgumentException("Cannot get blank layers.");
      }

      newStack.push(new Layer(new SimpleImageModel(layer.getImage().getWidth(),
          layer.getImage().getHeight(), layer.getImage().getPixels()), layer.getIsVisible(),
          layer.getLayerName()));
    }

    return newStack;
  }

  @Override
  public void setLayerName(int index, String layerName) {
    if (index < 0 || index > layerOfImages.size() - 1 || layerName == null) {
      throw new IllegalArgumentException("Index is invalid or layer name is null.");
    }

    layerOfImages.get(index).setLayerName(layerName);
  }

  @Override
  public Layer getLayer(String name) {
    for (int i = 0; i < layerOfImages.size(); i++) {

      if (layerOfImages.get(i).getLayerName().equals(name)) {
        return layerOfImages.get(i);
      }
    }

    throw new IllegalArgumentException("No such layer.");
  }

  @Override
  public void setCurrent(String name) {
    this.current = getLayer(name);
  }

  @Override
  public Layer getTopVisibleLayer() throws IllegalArgumentException {
    if (this.getAllLayers().isEmpty()) {
      throw new IllegalArgumentException("No layers available");
    }
    boolean result = false;
    Layer visibleLayer = null;

    for (Layer l : this.getAllLayers()) {
      if (l.getIsVisible()) {
        result = true;
        visibleLayer = new Layer(l.getImage(), l.getIsVisible(), l.getLayerName());
        break;
      }
    }

    if (result) {
      return visibleLayer;
    } else {
      throw new IllegalArgumentException("No visible layers");
    }
  }

  @Override
  public Layer getCurrent() {
    if (this.current == null) {
      throw new IllegalStateException("No current layer available.");
    }

    return this.current;
  }
}
