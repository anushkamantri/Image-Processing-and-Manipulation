package layeredimages;

import images.ImageModel;
import images.Pixel;
import images.SimpleImageModel;

/**
 * To represent one layer in a multi-layered image.
 */
public class Layer {

  private ImageModel<Pixel> img;
  private boolean isVisible;
  private String layerName;

  /**
   * Constructs a {@code Layer} object.
   *
   * @param img       the image in the layer
   * @param isVisible true if the layer is set to visible (default), false if it is transparent
   * @param layerName the name of the layer
   * @throws IllegalArgumentException if any arguments are null
   */
  public Layer(ImageModel<Pixel> img, boolean isVisible, String layerName) {
    if (img == null || layerName == null) {
      throw new IllegalArgumentException("Image or layer name can't be null.");
    }

    this.img = img;
    this.isVisible = isVisible;
    this.layerName = layerName;
  }


  /**
   * Gives a copy of the image in this layer.
   *
   * @return a copy of the image in this layer
   */
  public ImageModel<Pixel> getImage() {
    ImageModel<Pixel> imgCopy = new SimpleImageModel(img.getWidth(), img.getHeight(),
        img.getPixels());

    return imgCopy;
  }

  /**
   * Determines whether this layer is visible or not.
   *
   * @return true if this layer is visible, false otherwise
   */
  public boolean getIsVisible() {
    return this.isVisible;
  }

  /**
   * Gives the name of this layer.
   *
   * @return a copy of the image in this layer
   */
  public String getLayerName() {
    return layerName;
  }

  /**
   * Toggles the visibility of this layer.
   */
  public void changeLayerVisibility() {
    this.isVisible = !this.isVisible;
  }

  /**
   * Sets the name of this layer to the given name.
   *
   * @param name the name for this layer
   */
  public void setLayerName(String name) {
    layerName = name;
  }

  /**
   * Sets the image in this layer to the given image.
   *
   * @param image the image that the image in this layer is to be set to
   * @throws IllegalArgumentException if the given image is null
   */
  public void setImage(ImageModel<Pixel> image) throws IllegalArgumentException {
    if (image == null) {
      throw new IllegalArgumentException("Image is null");
    }
    this.img = image;
  }
}
