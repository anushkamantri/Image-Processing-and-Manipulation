package filters;

import images.ImageModel;
import images.SimpleImageModel;
import images.Pixel;
import images.Position2D;
import images.RGBClr;

/**
 * Abstract class to represent a filter to be applied on any image.
 */
public abstract class Filter {

  /**
   * Applies a given filter kernel to the given image to produce a filtered image.
   *
   * @param img    the given image to be filtered
   * @param kernel the filter kernel to be applied to the given image
   * @return the filtered image
   * @throws IllegalArgumentException if the given image or kernel is null or if the kernel is
   *                                  invalid for a filter
   */
  public ImageModel<Pixel> filterApplication(ImageModel<Pixel> img, double[][] kernel)
      throws IllegalArgumentException {
    if (img == null || kernel == null) {
      throw new IllegalArgumentException("Images.Image or kernel can't be null.");
    }

    if (kernel.length != kernel[0].length || kernel.length % 2 == 0) {
      throw new IllegalArgumentException("Invalid kernel.");
    }

    Pixel[][] filteredPixels = filterImage(img.getWidth(), img.getHeight(), img.getPixels(),
        kernel);

    return new SimpleImageModel(img.getWidth(), img.getHeight(), filteredPixels);
  }

  /**
   * Applies a filter to an image. Helper for filterApplication().
   *
   * @param width      width of the image
   * @param height     height of the image
   * @param pixelArray the pixels in the image
   * @param kernel     the filter to be applied to the image
   * @return a filtered array of pixels that form the image
   */
  private Pixel[][] filterImage(int width, int height, Pixel[][] pixelArray,
      double[][] kernel) {
    int kernelSize = kernel.length;
    Pixel[][] filteredArray = new Pixel[height][width];
    int edge = (int) Math.round((kernelSize - 1.0) / 2.0);

    for (int i = 0; i < height; i += 1) {
      for (int j = 0; j < width; j += 1) {
        Pixel[][] imageSection = getImageSection(i, j, pixelArray, kernelSize, edge);
        filteredArray[i][j] = applyFilterToSection(pixelArray[i][j], imageSection, kernel);
      }
    }

    return filteredArray;
  }

  /**
   * Gets a section of the image for a filter to be applied on.
   *
   * @param pixelRow    the row the pixel is in
   * @param pixelColumn the column the pixel is in
   * @param pixelArray  the pixels that form the image
   * @param kernelSize  the length of the kernel
   * @param edge        the edge of the kernel
   * @return a section of the image that is to be used to filter a pixel
   */
  private Pixel[][] getImageSection(int pixelRow, int pixelColumn, Pixel[][] pixelArray,
      int kernelSize, int edge) {
    Pixel[][] imageSection = new Pixel[kernelSize][kernelSize];

    for (int i = 0; i < kernelSize; i += 1) {
      for (int j = 0; j < kernelSize; j += 1) {
        try {
          imageSection[i][j] = pixelArray[i + (pixelRow - edge)][j + (pixelColumn - edge)];

        } catch (IndexOutOfBoundsException e) {
          imageSection[i][j] = new Pixel(new Position2D(i, j),
              new RGBClr(0, 0, 0));
        }
      }
    }
    return imageSection;
  }

  /**
   * Applies the given filter (kernel) to a pixel.
   *
   * @param p            the pixel to be filtered
   * @param imageSection the section of the image whose values are used to filter the given pixel
   * @param kernel       the filter to be applied
   * @return a new filtered pixel
   */
  private Pixel applyFilterToSection(Pixel p, Pixel[][] imageSection, double[][] kernel) {
    double newRedChannel = 0.0;
    double newGreenChannel = 0.0;
    double newBlueChannel = 0.0;

    for (int i = 0; i < kernel.length; i += 1) {
      for (int j = 0; j < kernel.length; j += 1) {
        newRedChannel += imageSection[i][j].getColor().getRedChannel() * kernel[i][j];
        newGreenChannel += imageSection[i][j].getColor().getGreenChannel() * kernel[i][j];
        newBlueChannel += imageSection[i][j].getColor().getBlueChannel() * kernel[i][j];
      }
    }

    return new Pixel(p.getPosition(), new RGBClr(newRedChannel, newGreenChannel, newBlueChannel));
  }
}
