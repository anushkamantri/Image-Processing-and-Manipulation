package filters;

import images.ImageModel;
import images.Pixel;
import images.Position2D;
import images.RGBClr;
import images.SimpleImageModel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * A class to create a mosaic effect on an image.
 */
public class MosaicFilter implements FilterCommand {

  private final int seeds;

  /**
   * Constructs a {@code MosaicFilter} object.
   *
   * @param seeds the number of seeds to be used in the filter
   * @throws IllegalArgumentException if the seeds are less than 1
   */
  public MosaicFilter(int seeds) {
    if (seeds < 1) {
      throw new IllegalArgumentException("Seeds are less than one");
    }
    this.seeds = seeds;
  }

  @Override
  public ImageModel<Pixel> filter(ImageModel<Pixel> img) {
    if (img == null) {
      throw new IllegalArgumentException("Null image");
    }

    ImageModel<Pixel> copyImage = new SimpleImageModel(img.getWidth(), img.getHeight(),
        img.getPixels());

    ImageModel<Pixel> result;

    if (seeds >= copyImage.getWidth() * copyImage.getHeight()) {
      result = copyImage;
    } else {
      List<Position2D> randomSeeds = getRandomSeeds(copyImage);

      for (int i = 0; i < img.getHeight(); i += 1) {
        for (int j = 0; j < img.getWidth(); j += 1) {
          List<Double> dist = new ArrayList<>();

          for (int k = 0; k < seeds; k += 1) {
            dist.add(Math.sqrt(((Math.pow(j - randomSeeds.get(k).getX(), 2))
                + (Math.pow(i - randomSeeds.get(k).getY(), 2)))));
          }

          randomSeeds.get(dist.indexOf(Collections.min(dist)))
              .addNeighborPixels(copyImage.getPixels()[i][j]);
        }
      }

      result = createMosaic(copyImage, randomSeeds);
    }
    return result;
  }

  /**
   * Creates an image model of the new mosaic image with the given number of seeds.
   *
   * @param copyImage   a copy of the image to which the mosaic filter is to be applied
   * @param randomSeeds the list of random seeds to be used to create the mosaic
   * @return an image model representing the mosaic image
   */
  private ImageModel<Pixel> createMosaic(ImageModel<Pixel> copyImage,
      List<Position2D> randomSeeds) {
    //ImageModel<Pixel> result
    Pixel[][] pixels = copyImage.getPixels();
    for (Position2D seed : randomSeeds) {
      for (Pixel p : seed.getNeighborPixels()) {
        pixels[(int) p.getPosition().getX()][(int) p.getPosition().getY()].setColor(
            averageColor(seed.getNeighborPixels()));
      }
    }
    return new SimpleImageModel(copyImage.getWidth(), copyImage.getHeight(), pixels);
  }

  /**
   * Gives the {@code RGBClr} whose components have been averaged using the cluster around the
   * seed.
   *
   * @param neighborPixels the neighboring cluster of pixels
   * @return an RGBClr with values that have been averaged using the cluster of neighboring pixels
   */
  private RGBClr averageColor(List<Pixel> neighborPixels) {
    RGBClr avgColor = new RGBClr(0, 0, 0);

    for (Pixel clr : neighborPixels) {
      avgColor.addColor(clr.getColor());
    }

    int red = avgColor.getRedChannel() / neighborPixels.size();
    int green = avgColor.getGreenChannel() / neighborPixels.size();
    int blue = avgColor.getBlueChannel() / neighborPixels.size();
    RGBClr finalClr;

    finalClr = new RGBClr(red, green, blue);

    return finalClr;
  }

  /**
   * Used to create a list of random {@code Position2D} objects that are to be used as seeds for the
   * mosaic image.
   *
   * @param img the image to be made a mosaic
   * @return the list of random seeds
   */
  private List<Position2D> getRandomSeeds(ImageModel<Pixel> img) {
    List<Position2D> randomSeeds = new ArrayList<>();
    Random r = new Random();
    int x;
    int y;

    while (randomSeeds.size() < seeds) {
      y = r.nextInt(img.getPixels()[0].length);
      x = r.nextInt(img.getPixels().length);

      Position2D pos = new Position2D(x, y);

      if (randomSeeds.size() == 0) {
        randomSeeds.add(pos);
      } else {
        for (int i = 0; i < randomSeeds.size(); i++) {
          if ((x != randomSeeds.get(i).getX() || y != randomSeeds.get(i).getY()) &&
              i == randomSeeds.size() - 1) {
            randomSeeds.add(pos);
          }
        }
      }
    }
    return randomSeeds;
  }
}
