package filters;


import images.ImageModel;
import images.Pixel;

/**
 * A class to apply the blur filter to an image.
 */
public class BlurFilter extends Filter implements FilterCommand {

  private double[][] kernel = {{0.0625, 0.125, 0.0625}, {0.125, 0.25, 0.125},
      {0.0625, 0.125, 0.0625}};

  @Override
  public ImageModel<Pixel> filter(ImageModel<Pixel> img) {
    return filterApplication(img, kernel);
  }
}
