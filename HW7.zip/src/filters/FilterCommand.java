package filters;

import images.ImageModel;
import images.Pixel;

/**
 * An interface for the filters that can be applied to an image.
 */
public interface FilterCommand {

  /**
   * Applies a filter to an image (ex: blur, sharpen).
   *
   * @return the filtered image
   */
  ImageModel<Pixel> filter(ImageModel<Pixel> img);
}
