package filters;

import images.ImageModel;
import images.Pixel;

/**
 * A class to apply the sharpen filter to an image.
 */
public class SharpenFilter extends Filter implements FilterCommand {

  private double[][] kernel = {{-0.125, -0.125, -0.125, -0.125, -0.125},
      {-0.125, 0.25, 0.25, 0.25, -0.125}, {-0.125, 0.25, 1, 0.25, -0.125},
      {-0.125, 0.25, 0.25, 0.25, -0.125}, {-0.125, -0.125, -0.125, -0.125, -0.125}};


  @Override
  public ImageModel<Pixel> filter(ImageModel<Pixel> img) {
    return filterApplication(img, kernel);
  }
}