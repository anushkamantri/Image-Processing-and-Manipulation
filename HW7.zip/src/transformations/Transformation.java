package transformations;

import images.ImageModel;
import images.SimpleImageModel;
import images.Pixel;
import images.RGBClr;

/**
 * Abstract class to represent a transformation to be applied on any image.
 */
public abstract class Transformation {

  /**
   * Applies a given transformation to the given image to produce a transformed image.
   *
   * @param img    the given image to be transformed
   * @param matrix the linear combination to be applied to the pixels of the given image
   * @return the transformed image
   * @throws IllegalArgumentException if the inputs are null or invalid for a transformation
   */
  protected ImageModel<Pixel> transformApplication(ImageModel<Pixel> img, double[][] matrix)
      throws IllegalArgumentException {
    if (img == null || matrix == null) {
      throw new IllegalArgumentException("Image or matrix can't be null.");
    }

    if (matrix.length != matrix[0].length || matrix.length != 3) {
      throw new IllegalArgumentException("Invalid transformation matrix.");
    }

    Pixel[][] transformedPixels = new Pixel[img.getHeight()][img.getWidth()];

    for (int i = 0; i < img.getHeight(); i += 1) {
      for (int j = 0; j < img.getWidth(); j += 1) {
        transformedPixels[i][j] = createNewPixel(img.getPixels()[i][j], matrix);
      }
    }
    return new SimpleImageModel(img.getWidth(), img.getHeight(), transformedPixels);
  }


  /**
   * Creates a transformed pixel by applying the given matrix (transformation) to the given pixel.
   *
   * @param p      the pixel to be transformed
   * @param matrix the transformation to be applied to the given pixel
   * @return a new transformed Pixel with clamped RGB values
   */
  private Pixel createNewPixel(Pixel p, double[][] matrix) {

    double[][] oldRGB = new double[3][1];
    oldRGB[0][0] = p.getColor().getRedChannel();
    oldRGB[1][0] = p.getColor().getGreenChannel();
    oldRGB[2][0] = p.getColor().getBlueChannel();

    double[][] newRGB = new double[3][1];

    for (int i = 0; i < 3; i += 1) {
      newRGB[i][0] = 0;
      for (int j = 0; j < 3; j += 1) {
        newRGB[i][0] += matrix[i][j] * oldRGB[j][0];
      }
    }

    RGBClr newColors = new RGBClr(newRGB[0][0], newRGB[1][0], newRGB[2][0]);
    Pixel result = new Pixel(p.getPosition(), newColors);

    return result;
  }

}
