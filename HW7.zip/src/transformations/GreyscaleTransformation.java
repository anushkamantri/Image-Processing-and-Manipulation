package transformations;

import images.ImageModel;
import images.Pixel;

/**
 * A class to apply the greyscale transformation to an image.
 */
public class GreyscaleTransformation extends Transformation implements TransformationCommand {

  private final double[][] matrix = {{0.2126, 0.7152, 0.0722}, {0.2126, 0.7152, 0.0722},
      {0.2126, 0.7152, 0.0722}};


  @Override
  public ImageModel<Pixel> transform(ImageModel<Pixel> img) {
    return transformApplication(img, matrix);
  }
}
