package transformations;

import images.ImageModel;
import images.Pixel;

/**
 * A class to apply the sepia transformation to an image.
 */
public class SepiaTransformation extends Transformation implements TransformationCommand {

  private final double[][] matrix = {{0.393, 0.769, 0.189}, {0.349, 0.686, 0.168},
      {0.272, 0.534, 0.131}};

  @Override
  public ImageModel<Pixel> transform(ImageModel<Pixel> img) {
    return transformApplication(img, matrix);
  }
}
