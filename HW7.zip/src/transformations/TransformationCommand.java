package transformations;

import images.ImageModel;
import images.Pixel;

/**
 * An interface to perform transformations on images.
 */
public interface TransformationCommand {

  /**
   * Transforms an image (ex: greyscale, sepia).
   *
   * @return the transformed image
   */
  ImageModel<Pixel> transform(ImageModel<Pixel> img);
}
