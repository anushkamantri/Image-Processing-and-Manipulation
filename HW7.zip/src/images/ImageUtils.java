package images;

/**
 * A class to contain utility methods for images.
 */
public class ImageUtils {

  /**
   * Clamps the RGB values so they do not go below the minimum (0) and do not exceed the maximum
   * (255).
   *
   * @param colorVal the value to be clamped
   * @return the clamped value for the given value
   */
  public int clampValues(double colorVal) {
    if (colorVal < 0.0) {
      return 0;
    }
    if (colorVal > 255.0) {
      return 255;
    } else {
      return (int) colorVal;
    }
  }
}
