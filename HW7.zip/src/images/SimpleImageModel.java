package images;

import filters.BlurFilter;
import filters.FilterCommand;
import filters.SharpenFilter;
import programmaticalimages.CheckerboardProgImage;
import programmaticalimages.ProgrammaticImages;
import transformations.GreyscaleTransformation;
import transformations.SepiaTransformation;
import transformations.TransformationCommand;

/**
 * A class to represent the inner workings and functionalities of an image. An SimpleImageModel can
 * be created by directly providing the dimensions and pixels of the image.
 */
public class SimpleImageModel implements ImageModel<Pixel> {

  private final int width;
  private final int height;
  private final Pixel[][] pixelsInImage;

  /**
   * Constructs a {@code SimpleImageModel} object with the given inputs.
   *
   * @param width         the width of the image
   * @param height        the height of the image
   * @param pixelsInImage the 2D array of the pixels in the image
   * @throws IllegalArgumentException if the array of pixels is null
   */
  public SimpleImageModel(double width, double height, Pixel[][] pixelsInImage)
      throws IllegalArgumentException {
    if (width < 0.0 || height < 0.0 || pixelsInImage == null) {
      throw new IllegalArgumentException(
          "Height or width must be greater than zero and pixels can't be null.");
    }

    this.width = (int) pixelsInImage[0].length;
    this.height = (int) pixelsInImage.length;
    this.pixelsInImage = new Pixel[this.height][this.width];

    for (int i = 0; i < getHeight(); i += 1) {
      for (int j = 0; j < getWidth(); j += 1) {
        Position2D copyPos = new Position2D(pixelsInImage[i][j].getPosition().getX(),
            pixelsInImage[i][j].getPosition().getY());

        RGBClr copyClr = new RGBClr(pixelsInImage[i][j].getColor().getRedChannel(),
            pixelsInImage[i][j].getColor().getGreenChannel(),
            pixelsInImage[i][j].getColor().getBlueChannel());

        this.pixelsInImage[i][j] = new Pixel(copyPos, copyClr);
      }
    }

  }

  @Override
  public int getWidth() {
    return width;
  }

  @Override
  public int getHeight() {
    return height;
  }

  @Override
  public Pixel[][] getPixels() {
    Pixel[][] copyPixels = new Pixel[getHeight()][getWidth()];
    for (int i = 0; i < getHeight(); i += 1) {
      for (int j = 0; j < getWidth(); j += 1) {
        Position2D copyPos = new Position2D(pixelsInImage[i][j].getPosition().getX(),
            pixelsInImage[i][j].getPosition().getY());

        RGBClr copyClr = new RGBClr(pixelsInImage[i][j].getColor().getRedChannel(),
            pixelsInImage[i][j].getColor().getGreenChannel(),
            pixelsInImage[i][j].getColor().getBlueChannel());

        copyPixels[i][j] = new Pixel(copyPos, copyClr);
      }
    }
    return copyPixels;
  }

  @Override
  public ImageModel<Pixel> getImage() {
    ImageModel<Pixel> imgCopy = new SimpleImageModel(this.getWidth(), this.getHeight(),
        this.getPixels());

    return imgCopy;
  }


  @Override
  public ImageModel<Pixel> filterUsing(String filterName) throws IllegalArgumentException {
    if (filterName == null) {
      throw new IllegalArgumentException("Filter name can't be null.");
    }

    String switchName = filterName.toLowerCase();
    FilterCommand cmd;
    ImageModel<Pixel> filteredImage = null;

    switch (switchName) {
      case "blur":
        cmd = new BlurFilter();
        break;

      case "sharpen":
        cmd = new SharpenFilter();
        break;

      default:
        throw new IllegalArgumentException("Unknown command " + filterName);
    }

    if (cmd != null) {
      filteredImage = cmd.filter(this.getImage());
    }
    return filteredImage;
  }

  @Override
  public ImageModel<Pixel> transformUsing(String transformationName)
      throws IllegalArgumentException {
    if (transformationName == null) {
      throw new IllegalArgumentException("Transformation name can't be null.");
    }

    String switchName = transformationName.toLowerCase();
    TransformationCommand cmd;
    ImageModel<Pixel> transformedImage;

    switch (switchName) {
      case "greyscale":
        cmd = new GreyscaleTransformation();
        break;

      case "sepia":
        cmd = new SepiaTransformation();
        break;

      default:
        throw new IllegalArgumentException("Unknown command " + transformationName);
    }

    transformedImage = cmd.transform(this.getImage());

    return transformedImage;
  }

  @Override
  public ImageModel<Pixel> createProgrammaticImageUsing(String progImageName, int tileSize,
      int tilesInARow, RGBClr[] clrs) throws IllegalArgumentException {

    if (progImageName == null || clrs == null) {
      throw new IllegalArgumentException("Programmatic image name or colors can't be null.");
    }

    String switchName = progImageName.toLowerCase();
    ProgrammaticImages cmd;
    ImageModel<Pixel> progImage = null;

    // replaced switch with if-else because of style grade. same with the next method.

    if ("checkerboard".equals(switchName)) {
      cmd = new CheckerboardProgImage(tileSize, tilesInARow, clrs);
    } else {
      throw new IllegalArgumentException("Unknown command " + progImageName);
    }

    if (cmd != null) {
      progImage = cmd.createProgrammaticImage();
    }
    return progImage;
  }
}
