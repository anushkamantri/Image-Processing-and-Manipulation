package images;

import java.util.Objects;

/**
 * To represent the red, green, and blue color channels of a pixel in an image.
 */
public class RGBClr {

  private double redChannel;
  private double greenChannel;
  private double blueChannel;

  /**
   * Constructs a {@code Images.RGBClr} object.
   *
   * @param redChannel   the RGB value of the red color in a pixel
   * @param greenChannel the RGB value of the green color in a pixel
   * @param blueChannel  the RGB value of the blue color in a pixel
   */

  public RGBClr(double redChannel, double greenChannel, double blueChannel) {
    if (redChannel < 0.0 || redChannel > 255.0 || greenChannel < 0.0 || greenChannel > 255.0
        || blueChannel < 0.0 || blueChannel > 255.0) {
      redChannel = new ImageUtils().clampValues(redChannel);
      greenChannel = new ImageUtils().clampValues(greenChannel);
      blueChannel = new ImageUtils().clampValues(blueChannel);
    }

    this.redChannel = redChannel;
    this.greenChannel = greenChannel;
    this.blueChannel = blueChannel;
  }

  /**
   * Gives the RGB value of the red color in a pixel.
   *
   * @return the RGB value of the red color
   */
  public int getRedChannel() {
    return (int) redChannel;
  }

  /**
   * Gives the RGB value of the green color in a pixel.
   *
   * @return the RGB value of the green color
   */
  public int getGreenChannel() {
    return (int) greenChannel;
  }

  /**
   * Gives the RGB value of the blue color in a pixel.
   *
   * @return the RGB value of the blue color
   */
  public int getBlueChannel() {
    return (int) blueChannel;
  }

  /**
   * Compares 2 {@code RGBClr} objects for equality.
   *
   * @param that the given RGBClr to be compared to this RGBClr
   * @return true if the two RGBColors are equal, false otherwise
   */
  public boolean equals(Object that) {
    if (this == that) {
      return true;
    }
    if (!(that instanceof RGBClr)) {
      return false;
    }
    RGBClr c = (RGBClr) that;
    return this.redChannel == c.redChannel
        && this.greenChannel == c.greenChannel
        && this.blueChannel == c.blueChannel;
  }

  /**
   * To give the hash code of this RGBClr.
   *
   * @return the hashcode for this RGBClr
   */
  public int hashCode() {
    return Objects.hash(redChannel, greenChannel, blueChannel);
  }


  /**
   * Increments a color to add the values of the given color.
   *
   * @param clr the color to be used for incrementing
   */
  public void addColor(RGBClr clr) {
    this.redChannel += clr.getRedChannel();
    this.greenChannel += clr.getGreenChannel();
    this.blueChannel += clr.getBlueChannel();
  }

}
