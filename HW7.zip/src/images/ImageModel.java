package images;

/**
 * An interface specifying the operations that can be performed on an {@code ImageModel<K>}.
 *
 * @param <K> the Pixel type
 */
public interface ImageModel<K> extends ImageState<K> {

  /**
   * To filter an image using the given filter name (ex: blur, sharpen).
   *
   * @param filterName the filter to be applied on the image
   * @return an {@code ImageModel<K>} corresponding to the resulting filtered image
   * @throws IllegalArgumentException if the given filter name is unknown/unsupported
   */
  ImageModel<K> filterUsing(String filterName) throws IllegalArgumentException;

  /**
   * To transform an image using the given filter name (ex: sepia, greyscale).
   *
   * @param transformationName the transformation to be applied on the image
   * @return an {@code ImageModel<K>} corresponding to the resulting transformed image
   * @throws IllegalArgumentException if the given transformation name is unknown/unsupported
   */
  ImageModel<K> transformUsing(String transformationName) throws IllegalArgumentException;

  /**
   * To create a programmatic image corresponding to the given programmatic image name (ex:
   * checkerboard), using the given tile size, the number of tiles in a row, and the given colors.
   *
   * @param progImageName the name of the programmatic image to be created
   * @param tileSize      the size of one tile in the image
   * @param tilesInARow   the number of tiles in one row of the image (since the image is a square,
   *                      this will also be the number of tiles in one column of the image)
   * @param clrs          the colors to be used in the image
   * @return an {@code ImageModel<K>} corresponding to the given specifications
   * @throws IllegalArgumentException if the given programmatic image name is unsupported
   */
  ImageModel<K> createProgrammaticImageUsing(String progImageName, int tileSize,
      int tilesInARow, RGBClr[] clrs) throws IllegalArgumentException;


}
