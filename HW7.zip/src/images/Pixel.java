package images;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * A class to represent a single pixel in an image. A pixel has a position in the image and a
 * color.
 */
public class Pixel {

  private Position2D position;
  private RGBClr color;
  private List<Pixel> neighborPixels = new ArrayList<>();


  /**
   * Constructs a {@code Pixel} object.
   *
   * @param position the position of the pixel in the image
   * @param color    the color of the pixel as RGB values
   */
  public Pixel(Position2D position, RGBClr color) {
    if (position == null || color == null) {
      throw new IllegalArgumentException("Position or color of a pixel can't be null.");
    }
    this.position = position;
    this.color = color;
  }

  /**
   * Gives the position of this pixel in the image.
   *
   * @return the {@code Images.Position2D} object of this pixel
   */
  public Position2D getPosition() {
    Position2D copyPos = new Position2D(position.getX(), position.getY());
    return copyPos;
  }

  /**
   * Gives the color of this pixel in the image.
   *
   * @return the {@code RGBClr} object of this pixel
   */
  public RGBClr getColor() {
    RGBClr copyClr = new RGBClr(color.getRedChannel(), color.getGreenChannel(),
        color.getBlueChannel());

    return copyClr;
  }

  /**
   * Adds a neighboring pixel for this seed.
   *
   * @param clr the pixel to be added
   */
  public void addNeighborColors(Pixel clr) {
    this.neighborPixels
        .add(new Pixel(clr.getPosition(), clr.getColor()));
  }

  /**
   * Gets the cluster of neighbouring pixels.
   *
   * @return the list of a cluster of pixels
   */
  public List<Pixel> getNeighborPixels() {
    List<Pixel> copyClrs = new ArrayList<>();
    for (int i = 0; i < neighborPixels.size(); i += 1) {
      Pixel rgb = neighborPixels.get(i);
      copyClrs.add(new Pixel(rgb.getPosition(), rgb.getColor()));
    }
    return copyClrs;
  }

  /**
   * Compares 2 {@code Pixel} objects for equality.
   *
   * @param that the given Images.Pixel to be compared to this Images.Pixel
   * @return true if the two Pixels are equal, false otherwise
   */
  public boolean equals(Object that) {
    if (this == that) {
      return true;
    }
    if (!(that instanceof Pixel)) {
      return false;
    }
    Pixel c = (Pixel) that;
    return this.position.equals(c.position)
        && this.color.equals(color);
  }

  /**
   * To give the hash code of this Pixel.
   *
   * @return the hashcode for this pixel
   */
  public int hashCode() {
    return Objects.hash(position, color);
  }

  /**
   * Changes the color of this pixel to the given color.
   *
   * @param clr the RGBClr
   */
  public void setColor(RGBClr clr) {
    if (clr == null) {
      throw new IllegalArgumentException("Null color not allowed");
    }
    this.color = new RGBClr(clr.getRedChannel(), clr.getGreenChannel(), clr.getBlueChannel());
  }
}
