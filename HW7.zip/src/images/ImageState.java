package images;

/**
 * An interface to represent an Image parameterized over a Pixel type, and return its
 * properties.
 *
 * @param <K> the Pixel type
 */
public interface ImageState<K> {

  /**
   * Gives the width of this image.
   *
   * @return the width of this image
   */
  int getWidth();

  /**
   * Gives the height of this image.
   *
   * @return the height of this image
   */
  int getHeight();

  /**
   * Gives all the pixels in this image.
   *
   * @return a 2D array of the pixels in this image
   */
  K[][] getPixels();

  /**
   * Gives this image.
   *
   * @return a copy of this image
   */
  ImageModel<K> getImage();


}
