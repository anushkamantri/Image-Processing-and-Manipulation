package images;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * To represent 2D (x, y) coordinates of a pixel in an image.
 */
public class Position2D {

  private final double x;
  private final double y;
  private List<Pixel> neighborPixels = new ArrayList<>();

  /**
   * Constructs a {@code Position2D} object.
   *
   * @param x the x coordinate
   * @param y the y coordinate
   */
  public Position2D(double x, double y) {
    this.x = x;
    this.y = y;
  }

  /**
   * Gives the x coordinate of this Position2D.
   *
   * @return the x coordinate of this position
   */
  public double getX() {
    return x;
  }

  /**
   * Gives the y coordinate of this 2DPosition.
   *
   * @return the y coordinate of this position
   */
  public double getY() {
    return y;
  }

  public void addNeighborPixels(Pixel p) {
    this.neighborPixels
        .add(new Pixel(p.getPosition(), p.getColor()));
  }

  /**
   * Gets the neighbor pixels for this seed.
   *
   * @return the list of neighboring pixels
   */
  public List<Pixel> getNeighborPixels() {
    List<Pixel> copyClrs = new ArrayList<>();
    for (int i = 0; i < neighborPixels.size(); i += 1) {
      Pixel pixel = neighborPixels.get(i);
      copyClrs.add(new Pixel(pixel.getPosition(), pixel.getColor()));
    }
    return copyClrs;
  }

  /**
   * Compares 2 {@code Position2D} objects for equality.
   *
   * @param that the given Position2D to be compared to this Images.Position2D
   * @return true if the two Position2Ds are equal, false otherwise
   */
  public boolean equals(Object that) {
    if (this == that) {
      return true;
    }
    if (!(that instanceof Position2D)) {
      return false;
    }
    Position2D c = (Position2D) that;
    return this.x == c.x
        && this.y == c.y;
  }

  /**
   * To give the hash code of this Position2D.
   *
   * @return the hashcode for this Position2D
   */
  public int hashCode() {
    return Objects.hash(x, y);
  }
}
