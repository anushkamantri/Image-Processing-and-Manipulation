package view;

import images.ImageModel;
import images.Pixel;
import javax.swing.JFileChooser;

/**
 * An interface for viewing classes that use GUI.
 */
public interface ViewGUI {

  /**
   * Retrieves the text that is input by the user in a given text area signified by the input
   * string.
   *
   * @param s the string used to identify the text area from which text is to be retrieved
   * @return the text in the corresponding text area
   */
  String getLayerText(String s);

  /**
   * Renders the given message onto the text area of the main panel.
   *
   * @param s the message to be rendered
   * @throws IllegalArgumentException if the given string is null
   */
  void renderMessage(String s) throws IllegalArgumentException;


  /**
   * Renders the image stored in the given model to the GUI to be viewed by the user.
   *
   * @param model the model corresponding to which an image is to be rendered
   */
  void renderImage(ImageModel<Pixel> model);

  /**
   * Gets the return value for a file.
   *
   * @param fchooser the file to be used to obtain the return value
   * @return an integer corresponding to the value returned by the file
   */
  int getFileValue(JFileChooser fchooser);


}
