package view;

import images.ImageModel;
import images.Pixel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import layeredimages.LayeredImageModel;
import layeredimagescontroller.GUIController;

/**
 * A class to make and handle the GUI for our image processing application.
 */
public class ViewOperations extends JFrame implements ViewGUI {

  private final JPanel mainPanel;
  private JMenu current;
  private JMenu create;
  private JTextArea textAreaCreate;
  private JTextArea textAreaCopy;
  private JTextArea textAreaVisibility;
  private JTextArea textAreaSaveAll;
  private JTextArea textAreaCurrent;
  private JTextArea textAreaRemove;
  private JTextArea textAreaSave;
  private JTextArea textAreaMosaic;
  private JLabel imageLabel;
  private final ActionListener controller;

  private JTextArea textAreaProgress;


  private final JMenuBar mb;


  /**
   * Constructs a {@code ViewOperations} object.
   *
   * @param model the layered image model to be used for the GUI
   */
  public ViewOperations(LayeredImageModel<Pixel> model) {
    super();
    if (model == null) {
      throw new IllegalArgumentException("Null model");
    }

    controller = new GUIController(model, this);
    JFrame frame = new JFrame();
    setTitle("Image Processing Application");
    setSize(1200, 1000);
    mainPanel = new JPanel();
    mainPanel.setBackground(Color.GRAY);
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
    add(mainPanel);
    current = new JMenu("Current");
    create = new JMenu("Create");
    mb = new JMenuBar();

    createImagePanel();
    createFileMenu();
    createEditMenu();
    createLayersMenu();
    add(mb, BorderLayout.NORTH);
  }

  /**
   * Creates the menu for Layers (operations on layers) that is to be added to the menu bar.
   */
  private void createLayersMenu() {
    JMenu layersMenu = new JMenu("Layers");

    JButton currentButton = new JButton("Enter");
    this.current = new JMenu("Current");
    this.textAreaCurrent = new JTextArea(5, 10);
    this.textAreaCurrent.setBorder(
        BorderFactory.createTitledBorder("Enter the name of the layer to be made current"));
    JPanel currentPanel = new JPanel(new FlowLayout());
    current.add(this.textAreaCurrent);
    currentPanel.add(currentButton);
    current.add(currentPanel);
    currentButton.setActionCommand("Current");
    currentButton.addActionListener(controller);

    JButton createButton = new JButton("Enter");
    this.create = new JMenu("Create");
    this.textAreaCreate = new JTextArea(5, 10);
    this.textAreaCreate.setBorder(
        BorderFactory.createTitledBorder("Enter the name of the layer to be made current"));
    JPanel createPanel = new JPanel(new FlowLayout());
    create.add(this.textAreaCreate);
    createPanel.add(createButton);
    create.add(createPanel);
    createButton.setActionCommand("Create");
    createButton.addActionListener(controller);

    JMenu copy = new JMenu("Copy");
    this.textAreaCopy = new JTextArea(5, 10);
    this.textAreaCopy.setBorder(BorderFactory.createTitledBorder("Enter layer to be copied"));
    JPanel copyPanel = new JPanel(new FlowLayout());
    JButton copyButton = new JButton("Enter");
    copyPanel.add(copyButton);
    copy.add(this.textAreaCopy);
    copy.add(copyPanel);
    copyButton.setActionCommand("Copy");
    copyButton.addActionListener(controller);

    JMenu visibility = new JMenu("Visibility");
    this.textAreaVisibility = new JTextArea(5, 10);
    this.textAreaVisibility.setBorder(
        BorderFactory.createTitledBorder("Enter layer to be made visible/invisible"));
    JPanel visibilityPanel = new JPanel(new FlowLayout());
    visibilityPanel.add(this.textAreaVisibility);
    JButton visibilityButton = new JButton("Enter");
    visibilityPanel.add(visibilityButton);
    visibility.add(this.textAreaVisibility);
    visibility.add(visibilityPanel);
    visibilityButton.setActionCommand("Visibility");
    visibilityButton.addActionListener(controller);

    JMenu remove = new JMenu("Remove");
    this.textAreaRemove = new JTextArea(5, 10);
    this.textAreaRemove.setBorder(BorderFactory.createTitledBorder("Enter layer to be removed"));
    JPanel removePanel = new JPanel(new FlowLayout());

    JButton removeButton = new JButton("Enter");
    removePanel.add(removeButton);
    remove.add(this.textAreaRemove);
    remove.add(removePanel);
    removeButton.setActionCommand("Remove");
    removeButton.addActionListener(controller);

    JMenuItem listOfLayers = new JMenuItem("Layer List");
    listOfLayers.setActionCommand("Layer List");
    listOfLayers.addActionListener(controller);

    JMenuItem visibleLayers = new JMenuItem("Visible Layers");
    visibleLayers.setActionCommand("Visible Layers");
    visibleLayers.addActionListener(controller);

    layersMenu.add(create);
    layersMenu.add(current);
    layersMenu.add(copy);
    layersMenu.add(visibility);
    layersMenu.add(remove);
    layersMenu.add(listOfLayers);
    layersMenu.add(visibleLayers);

    mb.add(layersMenu);
  }

  /**
   * Creates the menu for Edit (filters/transformations for the image) that is to be added to the
   * menu bar.
   */
  private void createEditMenu() {
    JMenu editMenu = new JMenu("Edit");
    JMenu filter = new JMenu("Filter");
    JMenu transform = new JMenu("Transform");

    JMenuItem blur = new JMenuItem("Blur");
    JMenuItem sharpen = new JMenuItem("Sharpen");
    JMenuItem sepia = new JMenuItem("Sepia");
    JMenuItem greyscale = new JMenuItem("Greyscale");

    blur.setActionCommand("Blur");
    blur.addActionListener(controller);

    sharpen.setActionCommand("Sharpen");
    sharpen.addActionListener(controller);

    sepia.setActionCommand("Sepia");
    sepia.addActionListener(controller);

    greyscale.setActionCommand("Greyscale");
    greyscale.addActionListener(controller);

    JMenu mosaic = new JMenu("Mosaic");
    this.textAreaMosaic = new JTextArea(5, 10);
    this.textAreaMosaic.setBorder(BorderFactory.createTitledBorder("Enter number of seeds"));
    JPanel mosaicPanel = new JPanel(new FlowLayout());

    JButton mosaicButton = new JButton("Enter");
    mosaicPanel.add(mosaicButton);
    mosaic.add(this.textAreaMosaic);
    mosaic.add(mosaicPanel);
    mosaicButton.setActionCommand("Mosaic");
    mosaicButton.addActionListener(controller);

    filter.add(sharpen);
    filter.add(blur);
    filter.add(mosaic);
    transform.add(sepia);
    transform.add(greyscale);

    editMenu.add(filter);
    editMenu.add(transform);
    mb.add(editMenu);
  }

  /**
   * Creates the menu for File (file operations for the image) that is to be added to the menu bar.
   */
  private void createFileMenu() {
    JMenu fileMenu = new JMenu("File");

    JMenu loadMenu = new JMenu("Load");
    JMenuItem loadAllMenu = new JMenuItem("Load All");
    JMenu saveMenu = new JMenu("Save As");
    JMenu saveAllMenu = new JMenu("Save All");

    loadAllMenu.setActionCommand("Load All");
    loadAllMenu.addActionListener(controller);

    this.textAreaSaveAll = new JTextArea(5, 10);
    this.textAreaSaveAll.setBorder(BorderFactory.createTitledBorder("Enter text file name"));
    JPanel saveAllPanel = new JPanel(new FlowLayout());
    JButton saveAllButton = new JButton("Enter");
    saveAllPanel.add(saveAllButton);
    saveAllMenu.add(this.textAreaSaveAll);
    saveAllMenu.add(saveAllPanel);
    saveAllButton.setActionCommand("Save All");
    saveAllButton.addActionListener(controller);

    this.textAreaSave = new JTextArea(5, 10);
    this.textAreaSave.setBorder(BorderFactory.createTitledBorder("File name with extension"));
    JPanel savePanel = new JPanel(new FlowLayout());
    JButton saveButton = new JButton("Enter");
    savePanel.add(saveButton);
    saveMenu.add(this.textAreaSave);
    saveMenu.add(savePanel);
    saveButton.setActionCommand("Save");
    saveButton.addActionListener(controller);

    JMenuItem checkerboard = new JMenuItem("Checkerboard");
    checkerboard.setActionCommand("Checkerboard");
    checkerboard.addActionListener(controller);

    JMenuItem upload = new JMenuItem("Upload");
    upload.setActionCommand("Upload");
    upload.addActionListener(controller);

    loadMenu.add(checkerboard);
    loadMenu.add(upload);

    fileMenu.add(loadMenu);
    fileMenu.add(loadAllMenu);
    fileMenu.add(saveMenu);
    fileMenu.add(saveAllMenu);

    mb.add(fileMenu);
  }

  /**
   * Creates the panel on which the image is displayed to the user.
   */
  private void createImagePanel() {
    JPanel imagePanel = new JPanel();
    imagePanel.setBorder(BorderFactory.createTitledBorder("Current Image"));
    imagePanel.setLayout(new GridLayout(1, 0, 10, 10));
    imagePanel.setPreferredSize(new Dimension(1200, 1000));
    imageLabel = new JLabel();
    imagePanel.add(imageLabel);

    JScrollPane imageScrollPane = new JScrollPane(imageLabel);

    JPanel progressPanel = new JPanel();
    progressPanel.setBorder(BorderFactory.createTitledBorder("Progress Status"));
    progressPanel.setLayout(new GridLayout(1, 0, 10, 10));
    progressPanel.setPreferredSize(new Dimension(1200, 500));
    JLabel progressLabel = new JLabel();
    progressPanel.add(progressLabel);
    textAreaProgress = new JTextArea(1200, 500);
    textAreaProgress.setBorder(BorderFactory.createTitledBorder("Progress"));
    progressPanel.add(textAreaProgress);

    JScrollPane progressScrollPane = new JScrollPane(progressLabel);
    progressPanel.add(progressScrollPane);

    imagePanel.add(imageScrollPane);
    mainPanel.add(imagePanel);
    mainPanel.add(progressPanel, BorderLayout.SOUTH);
  }

  @Override
  public String getLayerText(String s) {
    String result = "";
    if (s.equals("Create")) {
      result = this.textAreaCreate.getText();
    } else if (s.equals("Current")) {
      result = this.textAreaCurrent.getText();
    } else if (s.equals("Remove")) {
      result = this.textAreaRemove.getText();
    } else if (s.equals("Copy")) {
      result = this.textAreaCopy.getText();
    } else if (s.equals("Visibility")) {
      result = this.textAreaVisibility.getText();
    } else if (s.equals("Save")) {
      result = this.textAreaSave.getText();
    } else if (s.equals("Save All")) {
      result = this.textAreaSaveAll.getText();
    } else if (s.equals("Remove")) {
      result = this.textAreaRemove.getText();
    } else if (s.equals("Visible")) {
      result = this.textAreaRemove.getText();
    } else if (s.equals("Mosaic")) {
      result = this.textAreaMosaic.getText();
    }
    return result;
  }

  @Override
  public void renderMessage(String s) {
    if (s == null) {
      throw new IllegalArgumentException("Null string");
    }
    this.textAreaProgress.setText(s + "\n");
  }

  @Override
  public void renderImage(ImageModel<Pixel> img) {
    BufferedImage output = new BufferedImage(img.getWidth(), img.getHeight(),
        BufferedImage.TYPE_INT_RGB);

    for (int i = 0; i < img.getHeight(); i++) {
      for (int j = 0; j < img.getWidth(); j++) {
        int redChannel = img.getPixels()[i][j].getColor().getRedChannel();
        int greenChannel = img.getPixels()[i][j].getColor().getGreenChannel();
        int blueChannel = img.getPixels()[i][j].getColor().getBlueChannel();

        int rgbValue = new Color(redChannel, greenChannel, blueChannel).getRGB();

        output.setRGB(j, i, rgbValue);
      }
    }

    imageLabel.setIcon(new ImageIcon(output));
    this.repaint();
  }


  @Override
  public int getFileValue(JFileChooser fchooser) {
    return fchooser.showOpenDialog(ViewOperations.this);
  }
}


