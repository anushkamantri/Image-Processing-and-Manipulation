import images.ImageModel;
import images.Pixel;
import images.Position2D;
import images.RGBClr;
import images.SimpleImageModel;
import java.io.InputStreamReader;
import java.io.StringReader;
import javax.swing.JFrame;
import layeredimages.SimpleLayeredImageModel;
import layeredimagescontroller.BatchCommands;
import layeredimages.LayeredImageModel;
import view.ViewOperations;

/**
 * A class to store the main method.
 */
public class MainMethod {

  /**
   * The main method to run commands.
   *
   * @param args unused
   */
  public static void main(String[] args) {
    if (args == null) {
      return;
    }

    ViewOperations.setDefaultLookAndFeelDecorated(false);

    Pixel[][] pixels = new Pixel[200][200];
    for (int i = 0; i < 200; i++) {
      for (int j = 0; j < 200; j++) {
        pixels[i][j] = new Pixel(new Position2D(i, j),
            new RGBClr(0, 0, 0));
      }
    }

    ImageModel<Pixel> simple = new SimpleImageModel(200, 200, pixels);
    LayeredImageModel<Pixel> model = new SimpleLayeredImageModel(simple);
    if (args.length == 1) {
      if (args[0].equals("-text")) {
        new BatchCommands(model, System.out, new InputStreamReader(System.in), "interaction")
            .interaction();
      } else if (args[0].equals("-interactive")) {
        ViewOperations frame = new ViewOperations(model);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
      } else {
        System.out.println("Invalid command line argument");
        return;
      }
    } else if (args.length == 2 && args[0].equals("-script")) {
      new BatchCommands(model, System.out, new StringReader("script\n" + args[1] + "\n"))
          .interaction();
    } else {
      System.out.println("Invalid command line argument");
      return;
    }
  }
}

