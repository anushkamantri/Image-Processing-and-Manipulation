package programmaticalimages;

import images.ImageModel;
import images.SimpleImageModel;
import images.Pixel;
import images.Position2D;
import images.RGBClr;

/**
 * To create a checkerboard with the specified dimensions and colors. A checkerboard is like a chess
 * board, alternating between two colors.
 */
public class CheckerboardProgImage implements ProgrammaticImages {

  private final int tileSize;
  private final RGBClr[] colors;
  private final int tilesInARow;

  /**
   * Constructs a {@code CheckerboardProgImage} object.
   *
   * @param tileSize    the size of one tile in the checkerboard
   * @param tilesInARow height and width of the checkerboard
   * @param colors      the two colors to be used to make the board
   * @throws IllegalArgumentException if any inputs are invalid (less than 0, null, same colors, or
   *                                  colors less or more than 2)
   */
  public CheckerboardProgImage(int tileSize, int tilesInARow, RGBClr[] colors)
      throws IllegalArgumentException {
    if (tileSize < 0 || tilesInARow < 0 || colors == null || colors.length != 2
        || colors[0].equals(colors[1])) {
      throw new IllegalArgumentException(
          "Height or width must be greater than zero, colors can't be null and a checkerboard can "
              + "only have two distinct colors.");
    }

    this.tileSize = tileSize;
    this.tilesInARow = tilesInARow;
    this.colors = colors;
  }

  @Override
  public ImageModel<Pixel> createProgrammaticImage() {
    Pixel[][] checkerboard = new Pixel[tilesInARow][tilesInARow];

    for (int i = 0; i < tilesInARow; i += 1) {
      for (int j = 0; j < tilesInARow; j += 1) {
        if ((i + j) % 2 == 0) {
          createTile(checkerboard, colors[0], i, j);
        } else {
          createTile(checkerboard, colors[1], i, j);
        }
      }
    }
    return new SimpleImageModel(tilesInARow, tilesInARow,
        checkerboard);
  }

  /**
   * Creates a single tile for the checkerboard according to the tile size.
   *
   * @param checkerboard the board containing the tiles
   * @param color        the color of the tile to be created
   * @param boardRow     the row that the tile is to be added to
   * @param boardColumn  the column that the tile is to be added to
   */
  private void createTile(Pixel[][] checkerboard, RGBClr color, int boardRow, int boardColumn) {
    for (int m = 0; m < tileSize; m++) {
      for (int n = 0; n < tileSize; n++) {
        checkerboard[boardRow][boardColumn] = new Pixel(
            new Position2D((m + boardRow * tileSize), n + boardColumn * tileSize), color);
      }
    }
  }
}
