package programmaticalimages;

import images.ImageModel;
import images.Pixel;

/**
 * An interface to create images programmatically.
 */
public interface ProgrammaticImages {

  /**
   * To create an image programmatically.
   *
   * @return an {@code Image<Pixel>} created by programming
   */
  ImageModel<Pixel> createProgrammaticImage();
}
