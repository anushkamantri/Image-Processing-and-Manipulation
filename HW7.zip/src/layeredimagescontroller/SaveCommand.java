package layeredimagescontroller;

import images.Pixel;
import java.util.Scanner;
import layeredimages.Layer;
import layeredimages.LayeredImageModel;

/**
 * A class for the save command. Used to save the topmost visible layer of the image onto the
 * device.
 */
public class SaveCommand implements CommandController {

  private String fileName;

  /**
   * Creates a {@code Save} object.
   *
   * @param scanner scanner the scanner object for taking inputs
   * @throws IllegalArgumentException if no file name input is provided after the save
   */
  public SaveCommand(Scanner scanner) throws IllegalArgumentException {
    if (scanner.hasNext()) {
      fileName = scanner.next();
    } else {
      throw new IllegalArgumentException("No filename provided.");
    }
  }

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    boolean result = false;
    Layer visibleLayer = null;

    for (Layer l : model.getAllLayers()) {
      if (l.getIsVisible()) {
        result = true;
        visibleLayer = l;
        break;
      }
    }

    if (result) {
      saveHelp(visibleLayer, fileName);
    } else {
      throw new IllegalArgumentException("No visible layers to export.");
    }
  }


  /**
   * A helper for the go method. Saves an image to the device.
   *
   * @param l        the layer from which the image is to be saved
   * @param fileName the name of the file the image is to be saved to
   */
  private void saveHelp(Layer l, String fileName) {
    int index = fileName.indexOf('.');

    if (index == -1) {
      throw new IllegalArgumentException("No file extension provided.");
    }

    String extension = fileName.substring(index + 1);

    if (extension.equals("ppm")) {
      new ExportImagePPM(l.getImage(), fileName).exportImage();

    } else {
      new ExportImageNotPPM(l.getImage(), extension, fileName).exportImage();
    }
  }
}
