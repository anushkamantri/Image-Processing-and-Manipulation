package layeredimagescontroller;

import images.Pixel;
import layeredimages.LayeredImageModel;

/**
 * A class for the blur command. Used to apply the blur filter on the current layer.
 */
public class BlurCommand implements CommandController {

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    model.getCurrent().setImage(model.getCurrent().getImage().filterUsing("blur"));
  }
}
