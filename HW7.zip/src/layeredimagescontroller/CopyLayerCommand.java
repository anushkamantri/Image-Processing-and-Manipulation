package layeredimagescontroller;

import images.Pixel;
import java.util.Scanner;
import layeredimages.LayeredImageModel;

/**
 * A class for the copy command. Used to create a {@code Layer} in the layered image model that is
 * the same as another specified layer.
 */
public class CopyLayerCommand implements CommandController {

  private final String layerName;

  /**
   * Creates a {@code CopyLayerCommand} object.
   *
   * @param scanner object for taking inputs
   * @throws IllegalArgumentException if no layer index is provided after the copy
   */
  public CopyLayerCommand(Scanner scanner) {
    if (scanner.hasNext()) {
      layerName = scanner.next();
    } else {
      throw new IllegalArgumentException("No layer name to copy.");
    }
  }

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    model.addLayerCopy(layerName);
  }
}
