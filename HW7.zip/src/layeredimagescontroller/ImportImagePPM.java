package layeredimagescontroller;

import images.ImageModel;
import images.Pixel;
import images.Position2D;
import images.RGBClr;
import images.SimpleImageModel;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileInputStream;


/**
 * To read a PPM image from file and create an {@code SimpleImageModel} with the properties of the
 * PPM image.
 */
public class ImportImagePPM implements ImportImage {

  private final String fileName;

  /**
   * Constructs a {@code ImportImagePPM} object.
   *
   * @param fileName the name/file path of the file that the image is to be read from
   */
  public ImportImagePPM(String fileName) {
    if (fileName == null) {
      throw new IllegalArgumentException("File name can't be null.");
    }
    this.fileName = fileName;
  }

  @Override
  public ImageModel<Pixel> readFromFile() throws IllegalArgumentException {
    Scanner sc;

    try {
      sc = new Scanner(new FileInputStream(fileName));
    } catch (FileNotFoundException e) {
      throw new IllegalArgumentException("Couldn't read image.");
    }

    StringBuilder builder = new StringBuilder();
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (s.charAt(0) != '#') {
        builder.append(s).append(System.lineSeparator());
      }
    }

    sc = new Scanner(builder.toString());

    String token;

    token = sc.next();
    if (!token.equals("P3")) {
      System.out.println("Invalid PPM file: plain RAW file should begin with P3.");
    }

    int width = sc.nextInt();
    int height = sc.nextInt();
    Pixel[][] arrayOfPixels = new Pixel[height][width];
    sc.nextInt();

    ImageModel<Pixel> result = createImage(sc, width, height, arrayOfPixels);
    return result;
  }

  /**
   * Creates a {@code SimpleImageModel} by using the RGB values, width, and height of an image.
   *
   * @param sc            the scanner object used for iteration
   * @param width         width of the image
   * @param height        height of the image
   * @param arrayOfPixels the pixels in the image
   * @return an SimpleImageModel with the specified dimensions having the same RGB values as the
   *         image
   */
  private static ImageModel<Pixel> createImage(Scanner sc, int width, int height,
      Pixel[][] arrayOfPixels) {
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {

        int red = sc.nextInt();
        int green = sc.nextInt();
        int blue = sc.nextInt();

        RGBClr pixelColor = new RGBClr(red, green, blue);
        Position2D pixelPosition = new Position2D(i, j);
        Pixel pixelToAdd = new Pixel(pixelPosition, pixelColor);

        arrayOfPixels[i][j] = pixelToAdd;
      }
    }

    return new SimpleImageModel(width, height, arrayOfPixels);
  }
}
