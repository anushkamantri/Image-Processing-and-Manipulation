package layeredimagescontroller;

import images.Pixel;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
import layeredimages.Layer;
import layeredimages.LayeredImageModel;

/**
 * A class for the saveAll command. Used to save all layers containing an image and also create a
 * text file with the names of the layers and their export formats.
 */
public class SaveAllCommand implements CommandController {

  private final String extension;

  /**
   * Creates a {@code SaveAllCommand} object.
   *
   * @param sc the scanner object to read input
   */
  public SaveAllCommand(Scanner sc) {
    if (sc.hasNext()) {
      extension = sc.next();
    } else {
      throw new IllegalArgumentException("No extension provided.");
    }
  }

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    StringBuilder sb = new StringBuilder();

    for (Layer l : model.getAllLayers()) {
      sb.append(l.getLayerName() + "." + extension + " \n");

      if (extension.equals("ppm")) {
        new ExportImagePPM(l.getImage(), l.getLayerName() + ".ppm").exportImage();
      } else {
        new ExportImageNotPPM(
            l.getImage(), extension, l.getLayerName() + "." + extension).exportImage();
      }
    }

    try {
      FileOutputStream fos = new FileOutputStream("layerData.txt");
      fos.write(sb.toString().getBytes());
      fos.close();
    } catch (IOException e) {
      throw new IllegalArgumentException(("Could not write to file."));
    }
  }
}