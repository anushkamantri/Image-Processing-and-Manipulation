package layeredimagescontroller;

import images.Pixel;
import layeredimages.LayeredImageModel;

/**
 * A class for the greyscale command. Used to apply the greyscale transformation on the current
 * layer.
 */
public class GreyscaleCommand implements CommandController {

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    model.getCurrent().setImage(model.getCurrent().getImage().transformUsing("greyscale"));
  }

}
