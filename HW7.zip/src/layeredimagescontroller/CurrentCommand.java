package layeredimagescontroller;

import images.Pixel;
import java.util.Scanner;
import layeredimages.LayeredImageModel;

/**
 * A class for the current command. Used to make a layer the current layer in a layered image model
 * so that operations can be applied to it.
 */
public class CurrentCommand implements CommandController {

  private String name;

  /**
   * Creates a {@code Current} object.
   *
   * @param scanner the scanner object for taking inputs
   * @throws IllegalArgumentException if no layer name is provided after the current
   */
  public CurrentCommand(Scanner scanner) throws IllegalArgumentException {
    if (scanner.hasNext()) {
      this.name = scanner.next();
    } else {
      throw new IllegalArgumentException("Invalid name");
    }
  }

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    model.setCurrent(name);
  }
}
