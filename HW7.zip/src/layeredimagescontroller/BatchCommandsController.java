package layeredimagescontroller;

/**
 * The interface for the BatchCommands Controller.
 */
public interface BatchCommandsController {

  /**
   * Used to initiate interaction using commands.
   */
  void interaction();
}
