package layeredimagescontroller;

import images.Pixel;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.Scanner;
import layeredimages.LayeredImageModel;

/**
 * A class for the loadAll command. Used to load a layered image that was saved using the
 * application.
 */
public class LoadAllCommand implements CommandController {

  private final StringBuffer sb;

  /**
   * Creates a {@code CopyLayerCommand} object.
   *
   * @param scanner object for taking inputs
   * @throws IllegalArgumentException if no file name is provided after the loadAll or the file is
   *                                  null
   */
  public LoadAllCommand(Scanner scanner) throws IOException {
    File txtFile;
    if (scanner.hasNext()) {
      txtFile = new File(scanner.next());
    } else {
      throw new IllegalArgumentException("No file name provided.");
    }

    if (txtFile == null) {
      throw new IllegalArgumentException("Text file can't be null.");
    }

    BufferedReader br = new BufferedReader(new FileReader(txtFile));
    sb = new StringBuffer();
    String str;
    while ((str = br.readLine()) != null) {
      sb.append(str);
    }
  }

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    String input = sb.toString();
    String[] images = input.split("\\s+");
    String[] imageNames = new String[images.length];

    for (int i = 0; i < images.length; i++) {
      int index = images[i].indexOf('.');
      if (index == -1) {
        throw new IllegalArgumentException("No extension provided.");
      }
      imageNames[i] = images[i].substring(0, index);
    }

    StringBuilder interaction = new StringBuilder();
    interaction.append("interaction\n");

    for (int i = 0; i < images.length; i++) {
      interaction.append("create ").append(imageNames[i]).append("\n");
      interaction.append("current ").append(imageNames[i]).append("\n");
      interaction.append("load ").append(images[i]).append("\n");
    }

    BatchCommands bc = new BatchCommands(model, System.out,
        new StringReader(interaction.toString()));

    bc.interaction();
  }
}

