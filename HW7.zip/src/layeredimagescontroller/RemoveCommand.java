package layeredimagescontroller;

import images.Pixel;
import java.util.Scanner;
import layeredimages.LayeredImageModel;

/**
 * A class to remove a layer from an image model.
 */
public class RemoveCommand implements CommandController {

  private final String name;

  /**
   * Creates a {@code RemoveCommand} object.
   *
   * @param scanner the scanner for input
   */
  public RemoveCommand(Scanner scanner) {
    if (scanner.hasNext()) {
      this.name = scanner.next();
    } else {
      throw new IllegalArgumentException("No layer name provided.");
    }
  }

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    if (model == null) {
      throw new IllegalArgumentException("Model can't null.");
    }
    model.removeLayer(name);
  }
}
