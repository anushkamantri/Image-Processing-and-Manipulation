package layeredimagescontroller;

import images.Pixel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Function;
import layeredimages.LayeredImageModel;

/**
 * A class to hold all the valid commands for our image processing application and run them.
 */
public class BatchCommands implements BatchCommandsController {

  private final LayeredImageModel<Pixel> model;
  private final Appendable ap;
  private final Readable rd;
  Map<String, Function<Scanner, CommandController>> commands;
  private final String method;

  /**
   * Constructs a {@code BatchCommands} object.
   *
   * @param model the layered image model to which the commands are to be applied
   * @param ap    the appendable object used for interactions
   * @param rd    the readable object used for interactions
   */
  public BatchCommands(LayeredImageModel<Pixel> model, Appendable ap, Readable rd) {
    this.model = model;
    this.ap = ap;
    this.rd = rd;
    this.commands = new HashMap<>();
    this.method = "script";

    commands.put("create", sc -> new CreateCommand(sc));
    commands.put("current", sc -> new CurrentCommand(sc));
    commands.put("sepia", sc -> new SepiaCommand());
    commands.put("greyscale", sc -> new GreyscaleCommand());
    commands.put("sharpen", sc -> new SharpenCommand());
    commands.put("blur", sc -> new BlurCommand());
    commands.put("load", sc -> new LoadCommand(sc));
    commands.put("save", sc -> new SaveCommand(sc));
    commands.put("saveAll", sc -> new SaveAllCommand(sc));
    commands.put("visibility", sc -> new ToggleVisibilityCommand(sc));
    commands.put("copy", sc -> new CopyLayerCommand(sc));

    commands.put("loadAll", sc -> {
      try {
        return new LoadAllCommand(sc);
      } catch (IOException e) {
        handleRenderMessage("Load all failed.");
      }
      return null;
    });
  }

  /**
   * Constructs a {@code BatchCommands} object.
   *
   * @param model  the layered image model to which the commands are to be applied
   * @param ap     the appendable object used for interactions
   * @param rd     the readable object used for interactions
   * @param method the method of interaction
   */
  public BatchCommands(LayeredImageModel<Pixel> model, Appendable ap, Readable rd, String method) {
    this.model = model;
    this.ap = ap;
    this.rd = rd;
    this.commands = new HashMap<>();
    this.method = method;

    commands.put("create", sc -> new CreateCommand(sc));
    commands.put("current", sc -> new CurrentCommand(sc));
    commands.put("sepia", sc -> new SepiaCommand());
    commands.put("greyscale", sc -> new GreyscaleCommand());
    commands.put("sharpen", sc -> new SharpenCommand());
    commands.put("blur", sc -> new BlurCommand());
    commands.put("load", sc -> new LoadCommand(sc));
    commands.put("save", sc -> new SaveCommand(sc));
    commands.put("saveAll", sc -> new SaveAllCommand(sc));
    commands.put("visibility", sc -> new ToggleVisibilityCommand(sc));
    commands.put("copy", sc -> new CopyLayerCommand(sc));

    commands.put("loadAll", sc -> {
      try {
        return new LoadAllCommand(sc);
      } catch (IOException e) {
        handleRenderMessage("Load all failed.");
      }
      return null;
    });
  }

  /**
   * Used for interactions in the console.
   */
  public void interaction() {
    Scanner scanner = new Scanner(rd);

    handleRenderMessage("Interact with the console or input a script? (interaction/script)\n");
    String input = "";

    if (scanner.hasNext()) {
      input = scanner.next();

    }

    if (input.equals("Q") || input.equals("q")) {
      handleRenderMessage("Application quit.");
      return;
    }

    if (input.equals("interaction") || method.equals("interaction")) {
      handleInteraction(scanner);
    } else if (input.equals("script")) {
      try {
        handleScript(scanner);
      } catch (IOException e) {
        handleRenderMessage("Unable to read script.");
      }
    } else {
      handleRenderMessage("Invalid interaction method. Please try again.");
    }
  }

  /**
   * Attempts to output a message to the user.
   *
   * @param message the message to be displayed
   * @throws IllegalStateException if the appendable object fails to render the given message in the
   *                               view
   */
  private void handleRenderMessage(String message) throws IllegalArgumentException {
    try {
      ap.append(message);
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable object failed.");
    }
  }

  /**
   * To handle user interactions with the console.
   *
   * @param scanner the scanner object used for interactions
   */
  private void handleInteraction(Scanner scanner) {
    while (scanner.hasNext()) {
      String cmd = scanner.next();
      if (cmd.equals("Q") || cmd.equals("q")) {
        handleRenderMessage("Application quit.");
        return;
      }

      if (this.commands.containsKey(cmd)) {
        try {
          this.commands.get(cmd).apply(scanner).execute(model);
        } catch (IllegalArgumentException e) {
          handleRenderMessage("Invalid input. Try again. " + e.getMessage() + "\n");
        }
      } else {
        handleRenderMessage("No such command available.\n");
      }
    }
  }

  /**
   * To load a script that performs operations into the model.
   *
   * @param scanner the scanner object used for reading the script
   * @throws IOException if a line cannot be read from the BufferedReader object
   */
  private void handleScript(Scanner scanner) throws IOException {
    handleRenderMessage("Enter the script file name: ");
    if (scanner.hasNext()) {

      String filename = scanner.next();
      BufferedReader br = new BufferedReader(new FileReader(filename));
      StringBuffer sb = new StringBuffer();
      String str;
      while ((str = br.readLine()) != null) {
        sb.append(str);

        handleInteraction(new Scanner(sb.toString()));
      }
    }
  }
}
