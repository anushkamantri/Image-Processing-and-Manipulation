package layeredimagescontroller;

import images.Pixel;
import layeredimages.LayeredImageModel;

/**
 * A class for the sharpen command. Used to apply the sharpen filter on the current layer.
 */
public class SharpenCommand implements CommandController {

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    model.getCurrent().setImage(model.getCurrent().getImage().filterUsing("sharpen"));
  }
}
