package layeredimagescontroller;

import images.ImageModel;
import images.Pixel;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * A class to export an {@code Image<Pixel>} as a PPM image.
 */
public class ExportImagePPM implements ExportImage {

  private ImageModel<Pixel> img;
  private String outputFileName;

  /**
   * Constructs a {@code ExportImagePPM} object.
   *
   * @param img            the image to be exported
   * @param outputFileName the name of the file the image should be exported to
   * @throws IllegalArgumentException if the image or file name is null
   */
  public ExportImagePPM(ImageModel<Pixel> img, String outputFileName)
      throws IllegalArgumentException {
    if (img == null || outputFileName == null) {
      throw new IllegalArgumentException("Image or output file name can't be null.");
    }
    this.img = img;
    this.outputFileName = outputFileName;
  }

  @Override
  public void exportImage() throws IllegalArgumentException {
    int width = img.getWidth();
    int height = img.getHeight();

    StringBuilder textImage = new StringBuilder();
    textImage.append("P3\n").append(width + " ").append(height + "\n255\n");

    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        textImage.append((int) img.getPixels()[i][j].getColor().getRedChannel());
        textImage.append(" " + img.getPixels()[i][j].getColor().getGreenChannel());
        textImage.append(" " + img.getPixels()[i][j].getColor().getBlueChannel() + " ");
      }
    }

    String output = textImage.toString();

    try {
      FileOutputStream fos = new FileOutputStream(outputFileName);
      fos.write(output.getBytes());
      fos.close();
    } catch (IOException e) {
      throw new IllegalArgumentException(("Could not write to file."));
    }
  }
}
