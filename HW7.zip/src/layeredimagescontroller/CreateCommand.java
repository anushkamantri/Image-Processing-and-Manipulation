package layeredimagescontroller;

import images.Pixel;
import java.util.Scanner;
import layeredimages.LayeredImageModel;

/**
 * A class for the load command. Used to create a {@code Layer} in the layered image model.
 */
public class CreateCommand implements CommandController {

  private String name;

  /**
   * Creates a {@code Create} object.
   *
   * @param scanner object for taking inputs
   * @throws IllegalArgumentException if no layer name input is provided after the create
   */
  public CreateCommand(Scanner scanner) throws IllegalArgumentException {
    if (scanner.hasNext()) {
      this.name = scanner.next();
    } else {
      throw new IllegalArgumentException("No layer name provided.");
    }
  }

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    if (model == null) {
      throw new IllegalArgumentException("Model can't null.");
    }
    model.createLayer(name);
  }
}
