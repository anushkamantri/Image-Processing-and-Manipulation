package layeredimagescontroller;

/**
 * An interface for exporting images.
 */
public interface ExportImage {

  /**
   * To export an image to the device.
   *
   * @throws IllegalArgumentException if writing to a file failed
   */
  void exportImage() throws IllegalArgumentException;
}
