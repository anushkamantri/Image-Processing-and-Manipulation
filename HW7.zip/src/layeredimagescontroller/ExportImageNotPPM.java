package layeredimagescontroller;

import images.ImageModel;
import images.Pixel;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * A class to export images that are not in PPM format to the device.
 */
public class ExportImageNotPPM implements ExportImage {

  private final ImageModel<Pixel> img;
  private final String formatName;
  private final String outputFileName;

  /**
   * Creates a {@code ExportImageNotPPM} object.
   *
   * @param img            the image model to be used for exporting
   * @param formatName     the extension of the image file to be exported
   * @param outputFileName the name of the file the image is to be exported to
   */
  public ExportImageNotPPM(ImageModel<Pixel> img, String formatName, String outputFileName) {
    if (img == null || formatName == null || outputFileName == null) {
      throw new IllegalArgumentException("Arguments cannot be null!");
    }

    this.img = img;
    this.formatName = formatName;
    this.outputFileName = outputFileName;
  }

  @Override
  public void exportImage() throws IllegalArgumentException {
    BufferedImage output = new BufferedImage(img.getWidth(), img.getHeight(),
        BufferedImage.TYPE_INT_RGB);

    for (int i = 0; i < img.getHeight(); i++) {
      for (int j = 0; j < img.getWidth(); j++) {
        int redChannel = img.getPixels()[i][j].getColor().getRedChannel();
        int greenChannel = img.getPixels()[i][j].getColor().getGreenChannel();
        int blueChannel = img.getPixels()[i][j].getColor().getBlueChannel();

        int rgbValue = new Color(redChannel, greenChannel, blueChannel).getRGB();

        output.setRGB(j, i, rgbValue);
      }
    }

    try {
      ImageIO.write(output, formatName, new File(outputFileName));
    } catch (IOException e) {
      throw new IllegalArgumentException("Could not write to file.");
    }
  }
}
