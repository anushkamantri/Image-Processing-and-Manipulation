package layeredimagescontroller;

import images.Pixel;
import layeredimages.LayeredImageModel;

/**
 * A class for the sepia command. Used to apply the sepia transformation on the current
 * layer.
 */
public class SepiaCommand implements CommandController {

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    model.getCurrent().setImage(model.getCurrent().getImage().transformUsing("sepia"));

  }
}
