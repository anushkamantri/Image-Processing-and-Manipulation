package layeredimagescontroller;

import images.Pixel;
import java.util.Scanner;
import layeredimages.LayeredImageModel;

/**
 * A class to toggle the visibility of a layer. Used to switch the visibility of a layer on or off.
 */
public class ToggleVisibilityCommand implements CommandController {

  private final String layerName;

  /**
   * Creates a {@code ToggleVisibility} object.
   *
   * @param scanner the scanner object for taking inputs
   * @throws IllegalArgumentException if no layer number is provided after the visibility command or
   *                                  the layer number is less than 1
   */
  public ToggleVisibilityCommand(Scanner scanner) throws IllegalArgumentException {
    if (scanner.hasNext()) {
      layerName = scanner.next();
    } else {
      throw new IllegalArgumentException("No layer name provided.");
    }
  }


  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    model.getLayer(layerName).changeLayerVisibility();
  }
}
