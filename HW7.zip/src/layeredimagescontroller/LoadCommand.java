package layeredimagescontroller;

import images.Pixel;
import images.RGBClr;
import java.util.Scanner;
import layeredimages.LayeredImageModel;

/**
 * A class for the load command. Used to load a single image into our layered image model.
 */
public class LoadCommand implements CommandController {

  String s;

  /**
   * Creates a {@code Load} object.
   *
   * @param scanner the scanner object for taking inputs
   * @throws IllegalArgumentException if no further input is provided after the load
   */
  public LoadCommand(Scanner scanner) throws IllegalArgumentException {
    if (scanner.hasNext()) {
      s = scanner.next();
    } else {
      throw new IllegalArgumentException("No image to load is provided.");
    }
  }

  @Override
  public void execute(LayeredImageModel<Pixel> model) {

    if (s.equals("checkerboard")) {
      RGBClr[] checker = {new RGBClr(0, 0, 0),
          new RGBClr(255, 255, 255)};

      model.getCurrent().setImage(model.createProgrammaticImageUsing(s, 10, 100, checker));
    } else {
      int index = s.indexOf('.');

      if (index == -1) {
        throw new IllegalArgumentException("No file extension provided.");
      }

      String extension = s.substring(index);

      if (extension.equals("ppm")) {
        model.getCurrent().setImage(new ImportImagePPM(s).readFromFile());
      } else {
        model.getCurrent().setImage(new ImportImageNotPPM(s).readFromFile());
      }
    }
  }
}
