package layeredimagescontroller;

import images.ImageModel;
import images.Pixel;
import images.Position2D;
import images.RGBClr;
import images.SimpleImageModel;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;


/**
 * To read any non-PPM format image from file and create an {@code SimpleImageModel} with the
 * properties of the image.
 */
public class ImportImageNotPPM implements ImportImage {

  private final String fileName;

  /**
   * Constructs a {@code ImportImageNotPPM} object.
   *
   * @param fileName the name/file path of the file that the image is to be read from
   */
  public ImportImageNotPPM(String fileName) {
    if (fileName == null) {
      throw new IllegalArgumentException("File name can't be null.");
    }
    this.fileName = fileName;
  }

  @Override
  public ImageModel<Pixel> readFromFile() throws IllegalArgumentException {
    BufferedImage image;

    try {
      image = ImageIO.read(new File(fileName));
    } catch (IOException e) {
      throw new IllegalArgumentException("Couldn't read image.");
    }

    int height = image.getHeight();
    int width = image.getWidth();
    Pixel[][] arrayOfPixels = new Pixel[height][width];

    ImageModel<Pixel> result = createImage(image, width, height, arrayOfPixels);
    return result;
  }

  /**
   * Creates a {@code SimpleImageModel} by using the RGB values, width, and height of an image.
   *
   * @param image         the BufferedImage object used for getting the image's properties
   * @param width         width of the image
   * @param height        height of the image
   * @param arrayOfPixels the pixels in the image
   * @return an SimpleImageModel with the specified dimensions having the same RGB values as the
   *         image
   */
  private static ImageModel<Pixel> createImage(BufferedImage image, int width, int height,
      Pixel[][] arrayOfPixels) {
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        Color clr = new Color(image.getRGB(j, i));
        int red = clr.getRed();
        int green = clr.getGreen();
        int blue = clr.getBlue();

        RGBClr pixelColor = new RGBClr(red, green, blue);
        Position2D pixelPosition = new Position2D(i, j);
        Pixel pixelToAdd = new Pixel(pixelPosition, pixelColor);

        arrayOfPixels[i][j] = pixelToAdd;
      }
    }
    return new SimpleImageModel(width, height, arrayOfPixels);
  }
}

