package layeredimagescontroller;

import filters.MosaicFilter;
import images.Pixel;
import java.util.Scanner;
import layeredimages.LayeredImageModel;

/**
 * A class for the mosaic command. Used to apply the mosaic filter on the current layer.
 */
public class MosaicCommand implements CommandController {

  private final int seeds;

  /** Creates a {@code MosaicCommand} object.
   *
   * @param scanner the scanner object used to obtain the number of seeds
   * @throws IllegalArgumentException if no seeds are provided
   */
  public MosaicCommand(Scanner scanner) throws IllegalArgumentException {
    if (scanner.hasNext()) {
      this.seeds = scanner.nextInt();
    } else {
      throw new IllegalArgumentException("No seeds provided.");
    }
  }

  @Override
  public void execute(LayeredImageModel<Pixel> model) {
    model.getCurrent().setImage(new MosaicFilter(seeds).filter(model.getCurrent().getImage()));
  }
}

