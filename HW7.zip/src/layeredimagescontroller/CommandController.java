package layeredimagescontroller;

import images.Pixel;
import layeredimages.LayeredImageModel;

/**
 * An interface to support all the commands that may be applied to our layered image model.
 */
public interface CommandController {

  /**
   * Applies this command to the layered image model provided.
   *
   * @param model the model to have a command be applied to
   */
  void execute(LayeredImageModel<Pixel> model);
}
