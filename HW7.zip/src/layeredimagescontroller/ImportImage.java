package layeredimagescontroller;

import images.ImageModel;
import images.Pixel;

/**
 * An interface to import an image and convert it to a {@code Image<Pixel>}.
 */
public interface ImportImage {

  /**
   * To read an image from a file and convert it to a {@code Image<Pixel>}.
   *
   * @return the Image formed after converting
   * @throws IllegalArgumentException if reading from the file is unsuccessful
   */
  ImageModel<Pixel> readFromFile() throws IllegalArgumentException;
}
