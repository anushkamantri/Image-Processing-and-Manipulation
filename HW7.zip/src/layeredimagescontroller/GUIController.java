package layeredimagescontroller;

import images.ImageModel;
import images.Pixel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import layeredimages.Layer;
import layeredimages.LayeredImageModel;
import view.ViewGUI;

/**
 * A controller that acts as an action listener for the {@code ViewGUI} interface.
 */
public class GUIController implements ActionListener {

  private ViewGUI view;
  private LayeredImageModel<Pixel> model;


  /**
   * Constructs a {@code GUIController} object.
   *
   * @param model the model to be used with the controller
   * @param view  the view to be used with the controller
   */
  public GUIController(LayeredImageModel<Pixel> model, ViewGUI view) {
    this.view = view;
    this.model = model;

  }


  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      case "Create":
        try {
          String layerNameCreate = view.getLayerText("Create");
          new CreateCommand(new Scanner(layerNameCreate)).execute(model);
          view.renderMessage("Created layer " + layerNameCreate);
        } catch (IllegalArgumentException e1) {
          view.renderMessage("Process failed. " + e1.getMessage());
        }
        break;

      case "Current":
        try {
          String layerNameCurrent = view.getLayerText("Current");
          new CurrentCommand(new Scanner(layerNameCurrent)).execute(model);
          view.renderMessage("Current layer: " + layerNameCurrent);
        } catch (IllegalArgumentException e2) {
          view.renderMessage("Process failed. " + e2.getMessage());
        }
        break;

      case "Copy":
        try {
          String layerNameCopy = view.getLayerText("Copy");
          new CopyLayerCommand(new Scanner(layerNameCopy)).execute(model);
          view.renderMessage("Copied layer " + layerNameCopy);
        } catch (IllegalArgumentException e3) {
          view.renderMessage("Process failed. " + e3.getMessage());
        }
        break;

      case "Blur":
        try {
          view.renderMessage("Blurring...");
          new BlurCommand().execute(model);
          view.renderImage(model.getTopVisibleLayer().getImage());
          view.renderMessage("Blur applied");
        } catch (IllegalArgumentException e4) {
          view.renderMessage("Process failed. " + e4.getMessage());
        }
        break;

      case "Sepia":
        try {
          view.renderMessage("Applying Sepia...");
          new SepiaCommand().execute(model);
          view.renderImage(model.getTopVisibleLayer().getImage());
          view.renderMessage("Sepia applied");
        } catch (IllegalArgumentException e5) {
          view.renderMessage("Process failed. " + e5.getMessage());
        }
        break;

      case "Greyscale":
        try {
          view.renderMessage("Applying Greyscale...");
          new GreyscaleCommand().execute(model);
          view.renderMessage("Greyscale applied");
        } catch (IllegalArgumentException e6) {
          view.renderMessage("Process failed. " + e6.getMessage());
        }
        break;

      case "Sharpen":
        try {
          view.renderMessage("Sharpening...");
          new SharpenCommand().execute(model);
          view.renderImage(model.getTopVisibleLayer().getImage());
          view.renderMessage("Sharpen applied");
        } catch (IllegalArgumentException e7) {
          view.renderMessage("Process failed. " + e7.getMessage());
        }
        break;

      case "Mosaic":
        try {
          view.renderMessage("Applying Mosaic...");
          new MosaicCommand(new Scanner(view.getLayerText("Mosaic")))
              .execute(model);

          view.renderImage(model.getTopVisibleLayer().getImage());
          view.renderMessage("Mosaic applied");
        } catch (IllegalArgumentException e8) {
          view.renderMessage("Process failed. " + e8.getMessage());
        }
        break;

      case "Visibility":
        try {
          view.renderMessage("Changing visibility...");
          String layerNameVisibility = view.getLayerText("Visibility");
          new ToggleVisibilityCommand(new Scanner(layerNameVisibility)).execute(model);
          view.renderImage(model.getTopVisibleLayer().getImage());
          view.renderMessage("Layer " + layerNameVisibility + " is visible: " + model
              .getLayer(layerNameVisibility).getIsVisible());
        } catch (IllegalArgumentException e9) {
          view.renderMessage("Process failed. " + e9.getMessage());
        }
        break;

      case "Remove":
        try {
          String layerNameRemove = view.getLayerText("Remove");
          new RemoveCommand(new Scanner(layerNameRemove)).execute(model);
          view.renderMessage("Removed " + layerNameRemove);
          if (model.getAllLayers().size() == 0) {
            view.renderMessage("No layers to show");
          } else {
            view.renderImage(model.getTopVisibleLayer().getImage());
          }
        } catch (IllegalArgumentException e10) {
          view.renderMessage("Process failed. " + e10.getMessage());
        }
        break;

      case "Checkerboard":
        try {
          new LoadCommand(new Scanner("checkerboard")).execute(model);
          view.renderImage(model.getTopVisibleLayer().getImage());
          view.renderMessage("Created new checkerboard");
        } catch (IllegalArgumentException e11) {
          view.renderMessage("Process failed. " + e11.getMessage());
        }
        break;

      case "Upload":
        try {
          view.renderMessage("Uploading...");
          final JFileChooser fchooser = new JFileChooser(".");
          FileNameExtensionFilter filter = new FileNameExtensionFilter(
              "JPG, JPEG, PNG, PPM Images, TXT files", "ppm", "jpg", "jpeg", "png", "txt");
          fchooser.setFileFilter(filter);

          int retvalue = view.getFileValue(fchooser);

          if (retvalue == JFileChooser.APPROVE_OPTION) {
            File f = fchooser.getSelectedFile();

            String extension = f.getAbsolutePath()
                .substring(f.getAbsolutePath().lastIndexOf('.') + 1);

            ImageModel<Pixel> img;

            if (extension.equals("ppm")) {
              img = new ImportImagePPM(f.getAbsolutePath()).readFromFile();
              this.model.getCurrent().setImage(img);
              view.renderImage(model.getTopVisibleLayer().getImage());


            } else if (extension.equals("txt")) {

              String s = "script \n" + f.getAbsolutePath();

              BatchCommandsController controller = new BatchCommands(model, System.out,
                  new StringReader(s));
              controller.interaction();
              view.renderImage(model.getTopVisibleLayer().getImage());

            } else {
              img = new ImportImageNotPPM(f.getAbsolutePath()).readFromFile();
              this.model.getCurrent().setImage(img);
              view.renderImage(model.getTopVisibleLayer().getImage());
            }

          } else {
            view.renderMessage("Couldn't load image");
          }
          view.renderMessage("Uploaded new image");
        } catch (IllegalArgumentException e12) {
          view.renderMessage("Process failed. " + e12.getMessage());
        }
        break;

      case "Save":
        try {
          String outputFileName = view.getLayerText("Save");
          int index = outputFileName.lastIndexOf('.');

          if (index != -1) {
            new SaveCommand(new Scanner(outputFileName)).execute(model);
          } else {
            view.renderMessage("No extension provided");
          }
          view.renderMessage("Saved image as " + outputFileName);
        } catch (IllegalArgumentException e13) {
          view.renderMessage("Process failed. " + e13.getMessage());
        }
        break;

      case "Load All":
        try {
          final JFileChooser fchooserLoadAll = new JFileChooser(".");
          FileNameExtensionFilter filterLoadAll = new FileNameExtensionFilter(
              "TXT files", "txt");
          fchooserLoadAll.setFileFilter(filterLoadAll);

          int retvalueLoadAll = view.getFileValue(fchooserLoadAll);

          if (retvalueLoadAll == JFileChooser.APPROVE_OPTION) {
            File f = fchooserLoadAll.getSelectedFile();

            String extension = f.getAbsolutePath()
                .substring(f.getAbsolutePath().lastIndexOf('.') + 1);

            if (extension.equals("txt")) {

              try {
                new LoadAllCommand(new Scanner(f.getAbsolutePath())).execute(model);
                view.renderImage(model.getTopVisibleLayer().getImage());
              } catch (IOException ioException) {
                view.renderMessage("Could not load all images");
              }
            } else {
              view.renderMessage("Couldn't load all images");
            }
          }
          view.renderMessage("Load all complete");
        } catch (IllegalArgumentException e14) {
          view.renderMessage("Process failed. " + e14.getMessage());
        }
        break;

      case "Save All":
        try {
          new SaveAllCommand(new Scanner(view.getLayerText("Save All"))).execute(model);
          view.renderImage(model.getTopVisibleLayer().getImage());
          view.renderMessage("Saved all images");
        } catch (IllegalArgumentException e15) {
          view.renderMessage("Process failed. " + e15.getMessage());
        }
        break;

      case "Layer List":
        try {
          StringBuilder sb1 = new StringBuilder("All layers: \n");

          if (!model.getAllLayers().isEmpty()) {
            for (Layer l : model.getAllLayers()) {
              sb1.append(l.getLayerName() + "\n");
            }
          } else {
            sb1.append("No layers present.");
          }
          view.renderMessage(sb1.toString());
        } catch (IllegalArgumentException e16) {
          view.renderMessage("Process failed. " + e16.getMessage());
        }
        break;

      case "Visible Layers":
        try {
          StringBuilder sb2 = new StringBuilder("Visible layers: \n");

          if (!model.getAllLayers().isEmpty()) {
            for (Layer l : model.getAllLayers()) {
              if (l.getIsVisible()) {
                sb2.append(l.getLayerName() + "\n");
              }
              view.renderMessage(sb2.toString());
            }
          } else {
            sb2.append("No visible layers present");
          }
        } catch (IllegalArgumentException e17) {
          view.renderMessage("Process failed. " + e17.getMessage());
        }
        break;

      default:
        throw new IllegalArgumentException("Shouldn't reach this");
    }
  }
}



