package layeredimages;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import images.ImageModel;
import images.Pixel;
import images.Position2D;
import images.RGBClr;
import images.SimpleImageModel;
import java.io.StringReader;
import layeredimagescontroller.BatchCommands;
import org.junit.Before;
import org.junit.Test;
import programmaticalimages.CheckerboardProgImage;

/**
 * Tests for BatchCommands.
 */
public class BatchCommandsTest {

  Pixel[][] pixels = new Pixel[11][10];
  ImageModel<Pixel> simpleModel;
  LayeredImageModel<Pixel> model;
  BatchCommands bc;
  StringBuilder ap;
  StringReader rd;

  @Before
  public void initData() {
    for (int i = 0; i < 11; i++) {
      for (int j = 0; j < 10; j++) {
        pixels[i][j] = new Pixel(new Position2D(i, j),
            new RGBClr(100, 250, 50));
      }
    }

    simpleModel = new SimpleImageModel(10, 11, pixels);
    model = new SimpleLayeredImageModel(simpleModel);
    ap = new StringBuilder();
  }

  @Test
  public void testScriptAndInteraction() {
    rd = new StringReader("interaction q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();

    assertFalse(ap.toString().contains("Invalid interaction method. Please try again."));

    rd = new StringReader("script q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();

    assertFalse(ap.toString().contains("Invalid interaction method. Please try again."));
  }

  @Test
  public void testNonScriptAndInteraction() {
    rd = new StringReader("hi q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertTrue(ap.toString().contains("Invalid interaction method. Please try again."));
  }

  @Test
  public void testQuit() {
    rd = new StringReader("q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertTrue(ap.toString().contains("Application quit."));
  }


  @Test
  public void testNoCommandAvailable() {
    rd = new StringReader("interaction hi");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertTrue(ap.toString().contains("No such command available."));
  }

  @Test
  public void testCreateCommand() {
    rd = new StringReader("interaction create f1 q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertEquals(1, model.getAllLayers().size());
    assertEquals("f1", model.getAllLayers().get(0).getLayerName());
  }

  @Test(expected = IllegalStateException.class)
  public void testCurrentCommandException() {
    rd = new StringReader("interaction create f1 q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    model.getCurrent();
  }

  @Test
  public void testCurrentCommand() {
    rd = new StringReader("interaction create f1 current f1 q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertEquals("f1", model.getCurrent().getLayerName());
  }

  @Test
  public void testSepiaCommand() {
    rd = new StringReader("interaction create f1 current f1 load checkerboard sepia q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertEquals(238, model.getCurrent().getImage().getPixels()[9][4].getColor().getBlueChannel());
    assertEquals(255, model.getCurrent().getImage().getPixels()[9][4].getColor().getRedChannel());
    assertEquals(255, model.getCurrent().getImage().getPixels()[9][4].getColor().getGreenChannel());
  }

  @Test
  public void testGreyscaleCommand() {
    rd = new StringReader("interaction create f1 current f1 load checkerboard greyscale q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertEquals(254, model.getCurrent().getImage().getPixels()[9][4].getColor().getBlueChannel());
    assertEquals(254, model.getCurrent().getImage().getPixels()[9][4].getColor().getRedChannel());
    assertEquals(254, model.getCurrent().getImage().getPixels()[9][4].getColor().getGreenChannel());
  }

  @Test
  public void testBlurCommand() {
    rd = new StringReader("interaction create f1 current f1 load checkerboard blur q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertEquals(95, model.getCurrent().getImage().getPixels()[9][4].getColor().getBlueChannel());
    assertEquals(95, model.getCurrent().getImage().getPixels()[9][4].getColor().getRedChannel());
    assertEquals(95, model.getCurrent().getImage().getPixels()[9][4].getColor().getGreenChannel());
  }

  @Test
  public void testBlurSharpen() {
    rd = new StringReader("interaction create f1 current f1 load checkerboard sharpen q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertEquals(223, model.getCurrent().getImage().getPixels()[9][4].getColor().getBlueChannel());
    assertEquals(223, model.getCurrent().getImage().getPixels()[9][4].getColor().getRedChannel());
    assertEquals(223, model.getCurrent().getImage().getPixels()[9][4].getColor().getGreenChannel());
  }

  @Test
  public void testToggleVisibilityCommand() {
    rd = new StringReader("interaction create f1 create f2 visibility f2 q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertTrue(model.getLayer("f1").getIsVisible());
    assertFalse(model.getLayer("f2").getIsVisible());
  }

  @Test
  public void testLoadCommand() {
    rd = new StringReader("interaction create f1 current f1 load checkerboard q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();

    RGBClr[] checker = {new RGBClr(0, 0, 0),
        new RGBClr(255, 255, 255)};

    ImageModel<Pixel> checkerboard = new CheckerboardProgImage(10, 10, checker)
        .createProgrammaticImage();

    assertEquals(checkerboard.getPixels()[9][9].getColor(),
        model.getLayer("f1").getImage().getPixels()[9][9].getColor());
  }

  @Test
  public void testLoadCommandNoFileExtension() {
    rd = new StringReader("interaction create f1 current f1 load hi");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();

    assertTrue(ap.toString().contains("No file extension provided."));
  }

  @Test
  public void testCopyCommand() {
    rd = new StringReader("interaction create f1 copy f1 copy f1 q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();

    assertEquals(model.getLayer("f1").getImage().getWidth(),
        model.getLayer("copy_layer_f1_1").getImage().getWidth());

    assertEquals(model.getLayer("f1").getImage().getHeight(),
        model.getLayer("copy_layer_f1_1").getImage().getHeight());

    assertEquals(model.getLayer("f1").getImage().getPixels()[1][1],
        model.getLayer("copy_layer_f1_1").getImage().getPixels()[1][1]);

    assertEquals(model.getLayer("f1").getImage().getPixels()[1][1],
        model.getLayer("copy_layer_f1_2").getImage().getPixels()[1][1]);
  }

  @Test
  public void testSaveCommand() {
    rd = new StringReader("interaction create f1 visibility f1 save visibility.png q");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertTrue(ap.toString().contains("No visible layers to export."));
  }

  @Test
  public void testLoadAllCommand() {
    rd = new StringReader("interaction loadAll loadAllTestScript.txt");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    assertEquals(2, model.getAllLayers().size());
    assertEquals(model.getLayer("f2"), model.getCurrent());
  }

  @Test
  public void testSaveAllCommand() {
    rd = new StringReader("interaction create f1 current f1 load checkerboard sepia"
        + " create f2 current f2 load checkerboard saveAll png loadAll testLayerData.txt");

    bc = new BatchCommands(model, ap, rd);
    bc.interaction();

    RGBClr[] checker = {new RGBClr(0, 0, 0),
        new RGBClr(255, 255, 255)};

    ImageModel<Pixel> checkerboard = new CheckerboardProgImage(10, 10, checker)
        .createProgrammaticImage();

    ImageModel<Pixel> sepiaChecker = checkerboard.transformUsing("sepia");

    assertEquals(4, model.getAllLayers().size());
    assertEquals(model.getLayer("f1").getImage().getWidth(), sepiaChecker.getWidth());
    assertEquals(model.getLayer("f1").getImage().getHeight(), sepiaChecker.getHeight());
    assertEquals(
        model.getLayer("f1").getImage().getImage().getPixels()[0][0].getColor().getRedChannel(),
        sepiaChecker.getImage().getPixels()[0][0].getColor().getRedChannel());
    assertEquals(
        model.getLayer("f1").getImage().getImage().getPixels()[0][0].getColor().getBlueChannel(),
        sepiaChecker.getImage().getPixels()[0][0].getColor().getBlueChannel());
    assertEquals(
        model.getLayer("f1").getImage().getImage().getPixels()[0][0].getColor().getGreenChannel(),
        sepiaChecker.getImage().getPixels()[0][0].getColor().getGreenChannel());
  }

  @Test
  public void testScriptInteraction() {
    rd = new StringReader("script testScriptInteractions.txt");
    bc = new BatchCommands(model, ap, rd);
    bc.interaction();
    RGBClr[] checker = {new RGBClr(0, 0, 0),
        new RGBClr(255, 255, 255)};
    ImageModel<Pixel> checkerboard = new CheckerboardProgImage(10, 10, checker)
        .createProgrammaticImage();

    ImageModel<Pixel> sepiaChecker = checkerboard.transformUsing("sepia");

    assertEquals(2, model.getAllLayers().size());
    assertEquals(model.getLayer("pic2"), model.getCurrent());
    assertEquals(model.getLayer("pic1").getImage().getPixels()[0][0],
        sepiaChecker.getImage().getPixels()[0][0]);
    assertTrue(ap.toString().contains("Application quit."));
  }

}