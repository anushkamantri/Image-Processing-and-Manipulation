package layeredimages;

import static org.junit.Assert.assertEquals;

import images.ImageModel;
import images.Pixel;
import images.Position2D;
import images.RGBClr;
import images.SimpleImageModel;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests for the SimpleLayeredImageModel class.
 */
public class SimpleLayeredImageModelTest {

  Pixel[][] pixels = new Pixel[11][10];
  ImageModel<Pixel> simpleModel;
  LayeredImageModel<Pixel> model;

  @Before
  public void initData() {
    for (int i = 0; i < 11; i++) {
      for (int j = 0; j < 10; j++) {
        pixels[i][j] = new Pixel(new Position2D(i, j),
            new RGBClr(100, 250, 50));
      }
    }

    simpleModel = new SimpleImageModel(10, 11, pixels);
    model = new SimpleLayeredImageModel(simpleModel);
  }

  @Test
  public void testConstructor() {

    assertEquals(10, simpleModel.getWidth());
    assertEquals(11, simpleModel.getHeight());
    for (int i = 0; i < 11; i++) {
      for (int j = 0; j < 10; j++) {
        assertEquals(pixels[i][j], model.getPixels()[i][j]);
      }
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullConstructorException() {
    new SimpleLayeredImageModel(null);
  }

  @Test
  public void testGetImage() {
    ImageModel<Pixel> getModel = model.getImage();

    assertEquals(model.getHeight(), getModel.getHeight());
    assertEquals(model.getWidth(), getModel.getWidth());
    for (int i = 0; i < 11; i++) {
      for (int j = 0; j < 10; j++) {
        assertEquals(getModel.getPixels()[i][j], model.getPixels()[i][j]);
      }
    }
  }

  @Test
  public void testCreateLayer() {
    model.createLayer("f1");
    assertEquals(1, model.getAllLayers().size());
    assertEquals(11, model.getLayer("f1").getImage().getHeight());
    assertEquals(10, model.getLayer("f1").getImage().getWidth());

    model.createLayer("f2");
    assertEquals(2, model.getAllLayers().size());
    assertEquals(11, model.getLayer("f2").getImage().getHeight());
    assertEquals(10, model.getLayer("f2").getImage().getWidth());

  }
}