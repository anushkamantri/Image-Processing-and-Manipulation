import static org.junit.Assert.assertEquals;

import images.RGBClr;
import org.junit.Test;

/**
 * To test the RGBClr class.
 */
public class TestRGBColor {

  RGBClr blue = new RGBClr(0, 0, 255);
  RGBClr greenClamp = new RGBClr(0, 400, 0);
  RGBClr red = new RGBClr(100, -20, 0);

  @Test
  public void testClampAndGetters() {
    assertEquals(255, greenClamp.getGreenChannel(), 1);
    assertEquals(0, blue.getGreenChannel(), 1);
    assertEquals(255, blue.getBlueChannel(), 1);
    assertEquals(100, red.getRedChannel(), 1);
    assertEquals(0, red.getGreenChannel(), 1);
  }

  @Test
  public void testFieldsEquality() {
    assertEquals(new RGBClr(0, 0, 255), blue);

  }
}
