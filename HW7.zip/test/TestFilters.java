import static org.junit.Assert.assertEquals;

import filters.MosaicFilter;
import images.ImageModel;
import images.Pixel;
import images.RGBClr;
import java.util.Scanner;
import layeredimages.LayeredImageModel;
import layeredimages.SimpleLayeredImageModel;
import layeredimagescontroller.CreateCommand;
import layeredimagescontroller.CurrentCommand;
import layeredimagescontroller.MosaicCommand;
import programmaticalimages.CheckerboardProgImage;
import org.junit.Test;

/**
 * To test image filtering.
 */
public class TestFilters {

  CheckerboardProgImage checkerboardProgImage;
  RGBClr rgbClr = new RGBClr(2, 30, 72);
  RGBClr rgbClr2 = new RGBClr(40, 120, 204);
  RGBClr[] rgb = new RGBClr[]{rgbClr, rgbClr2};

  @Test
  public void testBlur() {
    checkerboardProgImage = new CheckerboardProgImage(20, 10, rgb);
    ImageModel<Pixel> img = checkerboardProgImage.createProgrammaticImage();
    assertEquals(72, img.getPixels()[1][1].getColor().getBlueChannel());
    assertEquals(204, img.getPixels()[2][1].getColor().getBlueChannel());

    ImageModel<Pixel> image = img.filterUsing("blur");

    assertEquals(138, image.getPixels()[1][1].getColor().getBlueChannel());
    assertEquals(21, image.getPixels()[1][1].getColor().getRedChannel());
    assertEquals(75, image.getPixels()[1][1].getColor().getGreenChannel());

    assertEquals(138, image.getPixels()[4][1].getColor().getBlueChannel());
    assertEquals(21, image.getPixels()[4][1].getColor().getRedChannel());
    assertEquals(75, image.getPixels()[4][1].getColor().getGreenChannel());

    assertEquals(103, image.getPixels()[9][4].getColor().getBlueChannel());
    assertEquals(15, image.getPixels()[9][4].getColor().getRedChannel());
    assertEquals(56, image.getPixels()[9][4].getColor().getGreenChannel());

    assertEquals(img.getPixels()[1][1].getPosition(), image.getPixels()[1][1].getPosition());
  }

  @Test
  public void testSharpen() {
    checkerboardProgImage = new CheckerboardProgImage(20, 10, rgb);
    ImageModel<Pixel> img = checkerboardProgImage.createProgrammaticImage();
    assertEquals(72, img.getPixels()[1][1].getColor().getBlueChannel());
    assertEquals(204, img.getPixels()[2][1].getColor().getBlueChannel());

    ImageModel<Pixel> image = img.filterUsing("sharpen");

    assertEquals(219, image.getPixels()[1][1].getColor().getBlueChannel());
    assertEquals(23, image.getPixels()[1][1].getColor().getRedChannel());
    assertEquals(108, image.getPixels()[1][1].getColor().getGreenChannel());

    assertEquals(255, image.getPixels()[4][1].getColor().getBlueChannel());
    assertEquals(55, image.getPixels()[4][1].getColor().getRedChannel());
    assertEquals(172, image.getPixels()[4][1].getColor().getGreenChannel());

    assertEquals(196, image.getPixels()[9][4].getColor().getBlueChannel());
    assertEquals(35, image.getPixels()[9][4].getColor().getRedChannel());
    assertEquals(112, image.getPixels()[9][4].getColor().getGreenChannel());

    assertEquals(img.getPixels()[2][1].getPosition(), image.getPixels()[2][1].getPosition());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidInput() {
    checkerboardProgImage = new CheckerboardProgImage(20, 10, rgb);
    ImageModel<Pixel> img = checkerboardProgImage.createProgrammaticImage();
    img.filterUsing("invalid");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullInput() {
    checkerboardProgImage = new CheckerboardProgImage(20, 10, rgb);
    ImageModel<Pixel> img = checkerboardProgImage.createProgrammaticImage();
    img.filterUsing(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullMosaic() {
    new MosaicFilter(-100);
  }

  @Test
  public void testMosaic() {

    checkerboardProgImage = new CheckerboardProgImage(20, 100, rgb);
    ImageModel<Pixel> img = checkerboardProgImage.createProgrammaticImage();
    assertEquals(72, img.getPixels()[1][1].getColor().getBlueChannel());
    assertEquals(204, img.getPixels()[2][1].getColor().getBlueChannel());
    LayeredImageModel<Pixel> layerModel = new SimpleLayeredImageModel(img);
    new CreateCommand(new Scanner("l1")).execute(layerModel);
    new CurrentCommand(new Scanner("l1")).execute(layerModel);
    new MosaicCommand(new Scanner("3")).execute(layerModel);
    ImageModel<Pixel> image = layerModel.getImage();

    assertEquals(219, image.getPixels()[1][1].getColor().getBlueChannel());
    assertEquals(23, image.getPixels()[1][1].getColor().getRedChannel());
    assertEquals(108, image.getPixels()[1][1].getColor().getGreenChannel());

    assertEquals(255, image.getPixels()[4][1].getColor().getBlueChannel());
    assertEquals(55, image.getPixels()[4][1].getColor().getRedChannel());

    assertEquals(196, image.getPixels()[9][4].getColor().getBlueChannel());
    assertEquals(35, image.getPixels()[9][4].getColor().getRedChannel());
    assertEquals(112, image.getPixels()[9][4].getColor().getGreenChannel());

    assertEquals(img.getPixels()[2][1].getPosition(), image.getPixels()[2][1].getPosition());
  }


}
