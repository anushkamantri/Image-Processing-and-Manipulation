import static org.junit.Assert.assertEquals;

import images.Position2D;
import org.junit.Test;

/**
 * To test the Position2D class.
 */
public class TestPosition2D {

  Position2D position2D = new Position2D(2, 4);
  Position2D position2DNeg = new Position2D(-2, 4);

  @Test
  public void testFields() {
    assertEquals(2, position2D.getX(), 0.1);
    assertEquals(4, position2D.getY(), 0.1);
    assertEquals(-2, position2DNeg.getX(), 0.1);
  }


  @Test
  public void testEquality() {
    assertEquals(new Position2D(2, 4), position2D);
  }
}
