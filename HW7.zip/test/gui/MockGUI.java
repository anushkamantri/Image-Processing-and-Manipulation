package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Mock setup.
 */
public class MockGUI implements ActionListener {

  String answer;
  private StringBuilder log;

  /**
   * Constructs a {@code MockGUI} object.
   *
   * @param log the string builder to confirm inputs
   */
  MockGUI(StringBuilder log) {
    this.log = log;
  }


  @Override
  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand().equals("Create")) {
      log.append("Created is complete");
    } else {
      answer = "Current";
    }
  }
}
