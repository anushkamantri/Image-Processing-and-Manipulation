package gui;

import static org.junit.Assert.assertEquals;

import images.ImageModel;
import images.Pixel;
import images.Position2D;
import images.RGBClr;
import images.SimpleImageModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import layeredimages.LayeredImageModel;
import layeredimages.SimpleLayeredImageModel;
import layeredimagescontroller.GUIController;
import org.junit.Before;
import org.junit.Test;
import view.ViewOperations;

/**
 * Testing GUI view.
 */

public class TestView {

  ImageModel<Pixel> simple;
  LayeredImageModel<Pixel> img;
  ActionListener controller;
  ViewOperations view;

  @Before
  public void init() {
    Pixel[][] pixels = new Pixel[100][100];
    for (int i = 0; i < 100; i++) {
      for (int j = 0; j < 100; j++) {
        pixels[i][j] = new Pixel(new Position2D(i, j),
            new RGBClr(30, 45, 100));
      }
    }
    simple = new SimpleImageModel(100, 100, pixels);
    img = new SimpleLayeredImageModel(simple);
    view = new ViewOperations(img);
    controller = new GUIController(img, view);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullInput() {
    new ViewOperations(null);
  }

  @Test
  public void testCreate() {

    ActionEvent a = new ActionEvent(view, 2, "Create");
    assertEquals(30, img.getImage().getPixels()[2][1].getColor().getRedChannel());
    new GUIController(img, view).actionPerformed(a);
    assertEquals(30, img.getImage().getPixels()[2][1].getColor().getRedChannel());
  }

  @Test
  public void testCurrentAndMosaic() {
    ViewOperations view = new ViewOperations(img);
    ActionEvent c = new ActionEvent(view, 2, "Create");
    ActionEvent b = new ActionEvent(view, 3, "Current");
    ActionEvent d = new ActionEvent(view, 1, "Mosaic");
    StringBuilder sb = new StringBuilder("layer1");
    assertEquals(30, img.getImage().getPixels()[2][1].getColor().getRedChannel());

    controller.actionPerformed(c);
    controller.actionPerformed(b);
    controller.actionPerformed(d);
    assertEquals(30, img.getImage().getPixels()[2][1].getColor().getRedChannel());
  }
}

