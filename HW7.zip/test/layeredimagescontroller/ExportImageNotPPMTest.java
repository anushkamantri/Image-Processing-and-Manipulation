package layeredimagescontroller;

import static org.junit.Assert.assertEquals;

import images.ImageModel;
import images.Pixel;
import images.RGBClr;
import images.SimpleImageModel;
import org.junit.Before;
import org.junit.Test;
import programmaticalimages.CheckerboardProgImage;

/**
 * Testing export functionality for PNG and JPEG format.
 */
public class ExportImageNotPPMTest {
  ImageModel<Pixel> checkerboard;
  ImageModel<Pixel> checkerboardImport;

  @Before
  public void initData() {

    RGBClr[] bw = {new RGBClr(0, 0, 0),
        new RGBClr(255, 255, 255)};

    checkerboard = new CheckerboardProgImage(20, 5, bw).createProgrammaticImage();

    ImageModel<Pixel> simpleExport = new SimpleImageModel(checkerboard.getWidth(),
        checkerboard.getHeight(), checkerboard.getPixels());

    new ExportImageNotPPM(simpleExport, "png",
        "checkerboardTestExport.png").exportImage();

    checkerboardImport = new ImportImageNotPPM("checkerboardTestExport.png")
        .readFromFile();
  }

  @Test
  public void testExportImage() {
    assertEquals(checkerboard.getWidth(), checkerboardImport.getWidth());
    assertEquals(checkerboard.getHeight(), checkerboardImport.getHeight());

    assertEquals(checkerboard.getPixels()[1][2].getColor().getBlueChannel(),
        checkerboardImport.getPixels()[1][2].getColor().getBlueChannel(), 0.01);

    assertEquals(checkerboard.getPixels()[1][2].getColor().getGreenChannel(),
        checkerboardImport.getPixels()[1][2].getColor().getGreenChannel(), 0.01);

    assertEquals(checkerboard.getPixels()[1][2].getColor().getRedChannel(),
        checkerboardImport.getPixels()[1][2].getColor().getRedChannel(), 0.01);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testExportImagConstructorExceptionsNullImage() {
    new ExportImageNotPPM(null, "hi", "hi");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExportImagConstructorExceptionsNullFile() {
    new ExportImageNotPPM(checkerboard, null, "hi");
  }
}