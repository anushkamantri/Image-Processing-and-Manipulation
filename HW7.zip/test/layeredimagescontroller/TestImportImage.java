import static org.junit.Assert.assertEquals;

import images.ImageModel;
import layeredimagescontroller.ImportImageNotPPM;
import layeredimagescontroller.ImportImagePPM;
import images.Pixel;
import images.Position2D;
import org.junit.Test;

/**
 * To test importing of images.
 */
public class TestImportImage {

  ImageModel<Pixel> importImagePPM = new ImportImagePPM("test1.ppm").readFromFile();
  ImageModel<Pixel> importImageNotPPM = new ImportImageNotPPM("panda-min.jpeg").readFromFile();

  @Test
  public void testReadFromFilePPM() {

    assertEquals(200, importImagePPM.getWidth());
    assertEquals(150, importImagePPM.getHeight());
    assertEquals(new Position2D(1, 2),
        importImagePPM.getPixels()[1][2].getPosition());
    assertEquals(123, importImagePPM.getPixels()[1][2].getColor().getRedChannel());
    assertEquals(85, importImagePPM.getPixels()[1][2].getColor().getBlueChannel());
    assertEquals(109, importImagePPM.getPixels()[1][2].getColor().getGreenChannel());
  }

  @Test
  public void testReadFromFileNotPPM() {

    assertEquals(300, importImageNotPPM.getWidth());
    assertEquals(264, importImageNotPPM.getHeight());
    assertEquals(new Position2D(1, 2),
        importImageNotPPM.getPixels()[1][2].getPosition());
    assertEquals(178, importImageNotPPM.getPixels()[1][2].getColor().getRedChannel());
    assertEquals(212, importImageNotPPM.getPixels()[1][2].getColor().getBlueChannel());
    assertEquals(202, importImageNotPPM.getPixels()[1][2].getColor().getGreenChannel());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullInput() {
    ImageModel<Pixel> importImagePPM = new ImportImagePPM(null).readFromFile();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullInputNotPPM() {
    ImageModel<Pixel> importImageNotPPM = new ImportImageNotPPM(null).readFromFile();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCouldntReadImagePPM() {
    ImageModel<Pixel> importImagePPM = new ImportImagePPM("noRead.ppm").readFromFile();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCouldntReadImageNotPPM() {
    ImageModel<Pixel> importImageNotPPM = new ImportImageNotPPM("noRead.jpeg").readFromFile();
  }
}

