import static org.junit.Assert.assertEquals;

import layeredimagescontroller.ExportImagePPM;
import images.ImageModel;
import layeredimagescontroller.ImportImagePPM;
import images.RGBClr;

import images.Pixel;
import images.SimpleImageModel;
import programmaticalimages.CheckerboardProgImage;
import org.junit.Before;
import org.junit.Test;

/**
 * A class to test image exporting.
 */
public class TestExport {

  ImageModel<Pixel> checkerboard;
  ImageModel<Pixel> checkerboardImport;

  @Before
  public void initData() {

    RGBClr[] bw = {new RGBClr(0, 0, 0),
        new RGBClr(255, 255, 255)};

    checkerboard = new CheckerboardProgImage(20, 5, bw).createProgrammaticImage();

    ImageModel<Pixel> simpleExport = new SimpleImageModel(checkerboard.getWidth(),
        checkerboard.getHeight(), checkerboard.getPixels());

    new ExportImagePPM(simpleExport, "checkerboardTestExport.ppm").exportImage();

    checkerboardImport = new ImportImagePPM("checkerboardTestExport.ppm")
        .readFromFile();
  }

  @Test
  public void testExportImage() {
    assertEquals(checkerboard.getWidth(), checkerboardImport.getWidth());
    assertEquals(checkerboard.getHeight(), checkerboardImport.getHeight());

    assertEquals(checkerboard.getPixels()[1][2].getColor().getBlueChannel(),
        checkerboardImport.getPixels()[1][2].getColor().getBlueChannel(), 0.01);

    assertEquals(checkerboard.getPixels()[1][2].getColor().getGreenChannel(),
        checkerboardImport.getPixels()[1][2].getColor().getGreenChannel(), 0.01);

    assertEquals(checkerboard.getPixels()[1][2].getColor().getRedChannel(),
        checkerboardImport.getPixels()[1][2].getColor().getRedChannel(), 0.01);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testExportImagConstructorExceptionsNullImage() {
    ExportImagePPM exportImagePPM = new ExportImagePPM(null, "hi");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExportImagConstructorExceptionsNullFile() {
    ExportImagePPM exportImagePPM = new ExportImagePPM(checkerboard, null);
  }

}
