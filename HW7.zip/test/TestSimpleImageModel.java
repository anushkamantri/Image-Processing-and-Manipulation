import static org.junit.Assert.assertEquals;

import images.ImageModel;
import images.Pixel;
import images.Position2D;
import images.RGBClr;
import images.SimpleImageModel;
import org.junit.Before;
import org.junit.Test;

/**
 * To test the SimpleImageModel class.
 */
public class TestSimpleImageModel {

  Pixel[][] pixels = new Pixel[11][10];

  @Before
  public void initData() {
    for (int i = 0; i < 11; i++) {
      for (int j = 0; j < 10; j++) {
        pixels[i][j] = new Pixel(new Position2D(1, 2), new RGBClr(1, 2, 3));
      }
    }
  }

  ImageModel<Pixel> simpleImageModel;

  @Test
  public void testReadConstructorAndObservers() {
    simpleImageModel = new SimpleImageModel(10, 11, pixels);
    assertEquals(10, simpleImageModel.getWidth());
    assertEquals(11, simpleImageModel.getHeight());

    for (int i = 0; i < 11; i++) {
      for (int j = 0; j < 10; j++) {
        assertEquals(pixels[i][j], simpleImageModel.getPixels()[i][j]);
      }
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullConstructorExceptions() {
    simpleImageModel = new SimpleImageModel(10, 11, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNegInputException() {
    simpleImageModel = new SimpleImageModel(10, -12, pixels);
  }

  @Test
  public void testGetImage() {
    simpleImageModel = new SimpleImageModel(10, 11, pixels);
    ImageModel<Pixel> getModel = simpleImageModel.getImage();

    assertEquals(simpleImageModel.getHeight(), getModel.getHeight());
    assertEquals(simpleImageModel.getWidth(), getModel.getWidth());
    for (int i = 0; i < 11; i++) {
      for (int j = 0; j < 10; j++) {
        assertEquals(getModel.getPixels()[i][j], simpleImageModel.getPixels()[i][j]);
      }
    }
  }
}
