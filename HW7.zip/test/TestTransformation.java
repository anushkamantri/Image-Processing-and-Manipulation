import static org.junit.Assert.assertEquals;

import images.ImageModel;
import images.Pixel;
import images.RGBClr;
import programmaticalimages.CheckerboardProgImage;
import org.junit.Test;

/**
 * To test image transformations.
 */
public class TestTransformation {

  CheckerboardProgImage checkerboardProgImage;
  RGBClr rgbClr = new RGBClr(2, 30, 72);
  RGBClr rgbClr2 = new RGBClr(40, 120, 204);
  RGBClr[] rgb = new RGBClr[]{rgbClr, rgbClr2};

  @Test
  public void testSepia() {
    checkerboardProgImage = new CheckerboardProgImage(20, 10, rgb);
    ImageModel<Pixel> img = checkerboardProgImage.createProgrammaticImage();

    assertEquals(72, img.getPixels()[1][1].getColor().getBlueChannel());
    assertEquals(204, img.getPixels()[2][1].getColor().getBlueChannel());

    ImageModel<Pixel> image = img.transformUsing("sepia");

    assertEquals(25, image.getPixels()[1][1].getColor().getBlueChannel());
    assertEquals(37, image.getPixels()[1][1].getColor().getRedChannel());
    assertEquals(33, image.getPixels()[1][1].getColor().getGreenChannel());

    assertEquals(101, image.getPixels()[4][1].getColor().getBlueChannel());
    assertEquals(146, image.getPixels()[4][1].getColor().getRedChannel());
    assertEquals(130, image.getPixels()[4][1].getColor().getGreenChannel());

    assertEquals(101, image.getPixels()[9][4].getColor().getBlueChannel());
    assertEquals(146, image.getPixels()[9][4].getColor().getRedChannel());
    assertEquals(130, image.getPixels()[9][4].getColor().getGreenChannel());

    assertEquals(img.getPixels()[1][1].getPosition(), image.getPixels()[1][1].getPosition());

  }

  @Test
  public void testGrey() {
    checkerboardProgImage = new CheckerboardProgImage(20, 10, rgb);
    ImageModel<Pixel> img = checkerboardProgImage.createProgrammaticImage();

    assertEquals(72, img.getPixels()[1][1].getColor().getBlueChannel());
    assertEquals(204, img.getPixels()[2][1].getColor().getBlueChannel());

    ImageModel<Pixel> image = img.transformUsing("greyscale");

    assertEquals(27, image.getPixels()[1][1].getColor().getBlueChannel());
    assertEquals(27, image.getPixels()[1][1].getColor().getRedChannel());
    assertEquals(27, image.getPixels()[1][1].getColor().getGreenChannel());

    assertEquals(109, image.getPixels()[4][1].getColor().getBlueChannel());
    assertEquals(109, image.getPixels()[4][1].getColor().getRedChannel());
    assertEquals(109, image.getPixels()[4][1].getColor().getGreenChannel());

    assertEquals(109, image.getPixels()[9][4].getColor().getBlueChannel());
    assertEquals(109, image.getPixels()[9][4].getColor().getRedChannel());
    assertEquals(109, image.getPixels()[9][4].getColor().getGreenChannel());

    assertEquals(img.getPixels()[2][1].getPosition(), image.getPixels()[2][1].getPosition());

  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidInput() {
    checkerboardProgImage = new CheckerboardProgImage(20, 10, rgb);
    ImageModel<Pixel> img = checkerboardProgImage.createProgrammaticImage();
    img.transformUsing("invalid");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullInput() {
    checkerboardProgImage = new CheckerboardProgImage(20, 10, rgb);
    ImageModel<Pixel> img = checkerboardProgImage.createProgrammaticImage();
    img.transformUsing(null);
  }
}
