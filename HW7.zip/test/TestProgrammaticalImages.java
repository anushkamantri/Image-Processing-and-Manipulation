import static org.junit.Assert.assertEquals;

import images.ImageModel;
import images.Pixel;
import images.RGBClr;
import programmaticalimages.CheckerboardProgImage;
import org.junit.Test;

/**
 * Tests to ensure that our checkerboard is constructed correctly. Checks false inputs and verifies
 * that tiles are in correct places.
 */
public class TestProgrammaticalImages {

  CheckerboardProgImage checkerboardProgImage;
  RGBClr rgbClr = new RGBClr(0, 0, 0);
  RGBClr rgbClr2 = new RGBClr(255, 255, 255);
  RGBClr[] rgb = new RGBClr[]{rgbClr, rgbClr2};
  RGBClr[] invalidRgb = new RGBClr[]{rgbClr};

  // Tests that the constructor throws exception when passed a null value.
  @Test(expected = IllegalArgumentException.class)
  public void testNullConstructor() {
    checkerboardProgImage = new CheckerboardProgImage(3, 2, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidTileSize() {
    checkerboardProgImage = new CheckerboardProgImage(-3, 10, rgb);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidTilesInARow() {
    checkerboardProgImage = new CheckerboardProgImage(20, -10, rgb);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidSameColor() {
    checkerboardProgImage =
        new CheckerboardProgImage(20, 10, new RGBClr[]{rgbClr, rgbClr});
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidRGBLength() {
    checkerboardProgImage = new CheckerboardProgImage(20, 10,
        new RGBClr[]{rgbClr, rgbClr2, new RGBClr(15, 20, 25)});
  }

  @Test
  public void testValidInput() {
    checkerboardProgImage = new CheckerboardProgImage(20, 10, rgb);
    ImageModel<Pixel> img = checkerboardProgImage.createProgrammaticImage();

    assertEquals(new RGBClr(0, 0, 0),
        img.getPixels()[1][1].getColor());

    assertEquals(new RGBClr(255, 255, 255),
        img.getPixels()[2][1].getColor());

    assertEquals(new RGBClr(255, 255, 255),
        img.getPixels()[1][2].getColor());

    assertEquals(59.0, img.getPixels()[2][1].getPosition().getX(), 0.1);
    assertEquals(19.0, img.getPixels()[0][0].getPosition().getX(), 0.1);
    assertEquals(19.0, img.getPixels()[0][0].getPosition().getY(), 0.1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidRGB() {
    checkerboardProgImage = new CheckerboardProgImage(2, 2, invalidRgb);

  }
}
